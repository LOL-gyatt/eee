import { pgTable, text, timestamp, bigserial, integer, index, uniqueIndex } from "drizzle-orm/pg-core";

// Invite secrets and guest tokens are stored only as SHA-256 hashes.
export const friendRoomsTable = pgTable("friend_rooms", {
  id: text("id").primaryKey(),
  keyHash: text("key_hash").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
}, t => [index("friend_rooms_expires_idx").on(t.expiresAt)]);

export const friendParticipantsTable = pgTable("friend_participants", {
  id: text("id").primaryKey(),
  roomId: text("room_id").notNull().references(() => friendRoomsTable.id, { onDelete: "cascade" }),
  nickname: text("nickname").notNull(),
  tokenHash: text("token_hash").notNull().unique(),
  joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  leftAt: timestamp("left_at", { withTimezone: true }),
}, t => [index("friend_participants_room_idx").on(t.roomId)]);

export const friendMessagesTable = pgTable("friend_messages", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  roomId: text("room_id").notNull().references(() => friendRoomsTable.id, { onDelete: "cascade" }),
  participantId: text("participant_id").notNull().references(() => friendParticipantsTable.id, { onDelete: "cascade" }),
  nickname: text("nickname").notNull(),
  body: text("body").notNull(),
  clientId: text("client_id").notNull(),
  length: integer("length").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, t => [index("friend_messages_room_idx").on(t.roomId, t.id), uniqueIndex("friend_messages_client_uq").on(t.participantId, t.clientId)]);

export type FriendRoom = typeof friendRoomsTable.$inferSelect;
export type FriendParticipantRow = typeof friendParticipantsTable.$inferSelect;
export type FriendMessageRow = typeof friendMessagesTable.$inferSelect;
