---
name: Xbox sync decisions
description: Why public OpenXBL lookup is used instead of Microsoft account sign-in.
---
Use OpenXBL public-profile lookup, not claims of authenticated Xbox account ownership.

**Why:** The user explicitly approved OpenXBL after Microsoft app registration was blocked. They initially rejected third-party services but subsequently changed that decision.

**How to apply:** Continue this integration rather than restarting Microsoft OAuth setup unless requested. Keep manual progress independent of synced data so unlinking does not destroy it.

OpenXBL title-history `totalAchievements` can be zero even when `currentAchievements` and Gamerscore show earned progress.

**Why:** Confirmed against live Bedrock Windows and iOS responses; a positive-total filter incorrectly hid valid titles.

**How to apply:** Do not interpret zero title-history totals as proof that a game has no achievements. Check the title-specific achievement response instead.

Keep only Xbox-provided last-online times; do not add tracker-observed last-seen timestamps.

**Why:** The user explicitly chose “Keep only Xbox-provided times” after being offered locally observed online times.

**How to apply:** Leave missing Xbox timestamps unavailable rather than estimating or maintaining a separate observed time.

Do not assume OpenXBL's documented legacy multi-XUID presence route actually supports batches.

**Why:** OpenXBL's documentation can advertise a batching contract that the live service rejects, and an HTTP 200 can still carry an error envelope. Relying only on the docs or transport status is insufficient.

**How to apply:** Verify provider envelope codes as well as HTTP status. Prefer the working single-player route with shared per-player caching, and lengthen refresh intervals for larger lists rather than increasing the existing tracker quota. Missing/private/error responses remain unknown, never offline.