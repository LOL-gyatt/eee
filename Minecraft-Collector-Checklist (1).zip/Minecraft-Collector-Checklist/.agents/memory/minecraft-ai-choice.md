---
name: Minecraft AI provider and context boundaries
description: Explicit final provider choice and privacy expectations for the Minecraft chatbot.
---
Use Replit AI Integrations for the Minecraft chatbot unless asked to change it.

**Why:** After considering free APIs and browser-local models, the user explicitly chose Replit AI with notice that credits apply. Do not reopen the rejected provider-selection flow.

**How to apply:** Chat context means messages entered in the app's own Minecraft chat. Do not fetch other Replit conversations or automatically include Xbox profile information; the user specifically questioned that boundary.