---
name: Minecraft visual direction
description: User's full-site Minecraft styling scope and rejection of generic dashboard styling.
---
The Minecraft visual direction applies to the whole website, including chat and friends tracking, not just the achievement bar. The user subsequently specified Minecraft Bedrock UI style.

**Why:** The user explicitly corrected the narrow scope: “bro not just that the top bar the whole website” and rejected the previous glowing trophy/dashboard treatment as not Minecraft-like.

**How to apply:** Keep new surfaces consistent with Bedrock-style gray layered panels, chunky gray/green controls and readable body text rather than rounded, glowing dashboard panels or noisy Java-style dirt textures. Preserve readability and real data.

Use normal Minecraft in-game-style lettering throughout, not a normal website sans-serif or decorative Silkscreen.

**Why:** After typography changes, the user explicitly corrected: “NO MINECRAFT NORMAL TEXT”.

**How to apply:** Interpret requests for normal Minecraft text as the familiar game UI letterforms, not an instruction to restore generic web fonts.
