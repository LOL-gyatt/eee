---
name: Minecraft achievement imagery
description: Which Minecraft Wiki achievement artwork matches the user's reference.
---
Use the Minecraft Wiki's illustrated NewAchievementSprite scenes when sourcing achievement imagery; the older AchievementSprite files are mostly item-only icons.

**Why:** Both are legitimate achievement assets, but the user's reference was character-and-scene artwork. Choosing square assets solely because the reference was square yielded the wrong visual style. The user also explicitly rejected generated art and repeated category-level images.

**How to apply:** Check an actual downloaded achievement image against the reference, not only its filename or dimensions. Preserve the artwork's aspect ratio and use each achievement's own image.