---
name: Friend chat scope
description: No-sign-in website chat scope and identity boundaries.
---
Friend chat must not require sign-in.

**Why:** The user explicitly requested “friend chat (no sign in)”.

**How to apply:** Keep chat separate from Xbox messaging and account ownership. Nicknames are unverified; possession of an invite grants room access, so communicate that clearly rather than presenting rooms as authenticated Xbox friend conversations.
