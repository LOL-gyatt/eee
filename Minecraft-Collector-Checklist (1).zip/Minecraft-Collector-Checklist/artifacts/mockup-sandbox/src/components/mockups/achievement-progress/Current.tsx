import { Compass, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import './_group.css';

// Copied from Home.tsx; only collection state and the reset side effect are stubbed.
function ProgressBar({ value, total, label, compact = false }: { value: number, total: number, label: string, compact?: boolean }) {
  const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div className="space-y-1.5 w-full">
      <div className={cn("flex justify-between font-bold", compact ? "text-xs" : "text-sm")}>
        <span className="text-muted-foreground uppercase tracking-wider">{label}</span>
        <span className="text-foreground">{value} <span className="text-muted-foreground/50 mx-0.5">/</span> {total} {compact ? "" : <span className="text-primary ml-1">({percentage}%)</span>}</span>
      </div>
      <div className={cn("bg-secondary rounded-full overflow-hidden border border-border relative", compact ? "h-2" : "h-3.5")}>
        <div
          className="h-full bg-primary transition-all duration-700 ease-out shadow-[inset_0_2px_4px_rgba(255,255,255,0.2)]"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

export function Current() {
  // Illustrative preview only: no account, API, or persistent collection state.
  const stats = { categories: { Achievement: { current: 126, total: 133 } } };
  const setIsResetOpen = (_open: boolean) => {};

  return (
    <div className="achievement-progress min-h-screen bg-background text-foreground selection:bg-primary/30 font-sans antialiased">
      <header className="border-b-4 border-border bg-card/80 sticky top-0 z-40 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-4 py-4 md:py-6 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center border-b-4 border-emerald-700 text-primary-foreground shadow-lg transform -rotate-6 transition-transform hover:rotate-0">
              <Compass size={32} className="stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight text-foreground uppercase">Blockbound</h1>
              <p className="text-primary font-bold text-sm tracking-widest uppercase opacity-90 -mt-0.5">Collector's Guide</p>
            </div>
          </div>

          <div className="flex-1 max-w-md w-full self-end md:self-auto space-y-3 hidden md:block">
             <ProgressBar value={stats.categories.Achievement.current} total={stats.categories.Achievement.total} label="Achievement Completion" />
          </div>

          <button
            onClick={() => setIsResetOpen(true)}
            className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary text-secondary-foreground hover:bg-destructive hover:text-destructive-foreground transition-all font-bold text-sm border-2 border-transparent hover:border-destructive/30"
          >
            <Trash2 size={18} />
            <span>Reset</span>
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 md:hidden">
        <div className="md:hidden flex flex-col gap-5 mb-8 bg-card p-5 rounded-3xl border-2 border-border shadow-sm relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-primary/5 rounded-full blur-2xl" />
          <ProgressBar value={stats.categories.Achievement.current} total={stats.categories.Achievement.total} label="Achievement Completion" />
        </div>
      </main>
    </div>
  );
}
