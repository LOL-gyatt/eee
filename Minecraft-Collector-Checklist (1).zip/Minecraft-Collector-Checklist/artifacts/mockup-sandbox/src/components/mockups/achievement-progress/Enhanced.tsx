import { useId } from 'react';
import { Compass, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import './_group.css';

// Mirrors blockbound-collector/src/components/AchievementProgress.tsx
const SEGMENTS = 18;
const pixel = { fontFamily: "'Silkscreen', 'Courier New', monospace" } as const;
const xpText = { ...pixel, textShadow: '2px 2px 0 #1a1a1a, -1px 0 0 #1a1a1a, 0 -1px 0 #1a1a1a' } as const;

export function AchievementProgress({ value, total, label = 'Achievement Completion', className }: { value: number, total: number, label?: string, className?: string }) {
  const safeTotal = Math.max(0, total);
  const safeValue = Math.min(Math.max(0, value), safeTotal);
  const exact = safeTotal > 0 ? (safeValue / safeTotal) * 100 : 0;
  const percentage = safeValue === safeTotal && safeTotal > 0 ? 100 : Math.min(99, Math.floor(exact));
  const labelId = useId();

  return (
    <div
      className={cn("w-full p-2 pt-1.5 bg-[#2b2b2b] border-2 border-[#0f0f0f] shadow-[inset_2px_2px_0_#4a4a4a,inset_-2px_-2px_0_#161616]", className)}
      style={{ borderRadius: 0 }}
    >
      <div className="flex items-baseline justify-between gap-2 mb-1 leading-none">
        <span id={labelId} style={pixel} className="text-[13px] uppercase text-[#e0e0e0] truncate">{label}</span>
        <span style={xpText} className="text-lg text-[#80ff20] tabular-nums whitespace-nowrap">
          {safeValue}<span className="text-[#c6c6c6]">/</span>{safeTotal}
          <span className="ml-2 text-[#fcdb3c]">{percentage}%</span>
        </span>
      </div>
      <div
        role="progressbar"
        aria-labelledby={labelId}
        aria-valuemin={0}
        aria-valuemax={safeTotal}
        aria-valuenow={safeValue}
        aria-valuetext={`${safeValue} of ${safeTotal} achievements, ${percentage}%`}
        className="relative h-[14px] bg-[#1f1f1f] border-2 border-[#0a0a0a]"
      >
        <div
          className="absolute inset-y-0 left-0 bg-[#7ecf2a] shadow-[inset_0_3px_0_#b4f55a,inset_0_-3px_0_#3f7a12] motion-safe:transition-[width] motion-safe:duration-500 motion-safe:ease-[steps(8)]"
          style={{ width: `${exact}%` }}
        />
        <div aria-hidden="true" className="absolute inset-0 flex">
          {Array.from({ length: SEGMENTS }, (_, i) => (
            <span key={i} className={cn("flex-1", i < SEGMENTS - 1 && "border-r-2 border-[#0a0a0a]")} />
          ))}
        </div>
      </div>
    </div>
  );
}
export function Enhanced() {
  // Illustrative preview only: no account, API, or persistent collection state.
  const stats = { categories: { Achievement: { current: 126, total: 133 } } };
  const setIsResetOpen = (_open: boolean) => {};

  return (
    <div className="achievement-progress min-h-screen bg-background text-foreground selection:bg-primary/30 font-sans antialiased">
      <header className="border-b-4 border-border bg-card/80 sticky top-0 z-40 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-4 py-4 md:py-6 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center border-b-4 border-emerald-700 text-primary-foreground shadow-lg transform -rotate-6 transition-transform hover:rotate-0">
              <Compass size={32} className="stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight text-foreground uppercase">Blockbound</h1>
              <p className="text-primary font-bold text-sm tracking-widest uppercase opacity-90 -mt-0.5">Collector's Guide</p>
            </div>
          </div>

          <div className="flex-1 max-w-md w-full self-end md:self-auto space-y-3 hidden md:block">
             <AchievementProgress value={stats.categories.Achievement.current} total={stats.categories.Achievement.total} />
          </div>

          <button
            onClick={() => setIsResetOpen(true)}
            className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary text-secondary-foreground hover:bg-destructive hover:text-destructive-foreground transition-all font-bold text-sm border-2 border-transparent hover:border-destructive/30"
          >
            <Trash2 size={18} />
            <span>Reset</span>
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 md:hidden">
        <div className="md:hidden flex flex-col gap-5 mb-8 bg-card p-5 rounded-3xl border-2 border-border shadow-sm relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-primary/5 rounded-full blur-2xl" />
          <AchievementProgress value={stats.categories.Achievement.current} total={stats.categories.Achievement.total} />
        </div>
      </main>
    </div>
  );
}
