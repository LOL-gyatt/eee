import { useId } from 'react';
import { cn } from '@/lib/utils';

const SEGMENTS = 18;

export function AchievementProgress({ value, total, label = 'Achievement Completion', className }: { value: number, total: number, label?: string, className?: string }) {
  const safeTotal = Math.max(0, total);
  const safeValue = Math.min(Math.max(0, value), safeTotal);
  const exact = safeTotal > 0 ? (safeValue / safeTotal) * 100 : 0;
  const percentage = safeValue === safeTotal && safeTotal > 0 ? 100 : Math.min(99, Math.floor(exact));
  const labelId = useId();

  return (
    <div
      className={cn("w-full p-2 pt-1.5 bg-[#2b2b2b] border-2 border-[#0f0f0f] shadow-[inset_2px_2px_0_#4a4a4a,inset_-2px_-2px_0_#161616]", className)}
      style={{ borderRadius: 0 }}
    >
      <div className="flex flex-wrap items-baseline justify-between gap-x-2 gap-y-1 mb-1.5 leading-snug">
        <span id={labelId} className="text-sm font-semibold text-[#e0e0e0]">{label}</span>
        <span className="text-lg font-bold text-[#80ff20] tabular-nums whitespace-nowrap">
          {safeValue}<span className="text-[#c6c6c6]">/</span>{safeTotal}
          <span className="ml-2 text-[#fcdb3c]">{percentage}%</span>
        </span>
      </div>
      <div
        role="progressbar"
        aria-labelledby={labelId}
        aria-valuemin={0}
        aria-valuemax={safeTotal}
        aria-valuenow={safeValue}
        aria-valuetext={`${safeValue} of ${safeTotal} achievements, ${percentage}%`}
        className="relative h-[14px] bg-[#1f1f1f] border-2 border-[#0a0a0a]"
      >
        <div
          className="absolute inset-y-0 left-0 bg-[#7ecf2a] shadow-[inset_0_3px_0_#b4f55a,inset_0_-3px_0_#3f7a12] motion-safe:transition-[width] motion-safe:duration-500 motion-safe:ease-[steps(8)]"
          style={{ width: `${exact}%` }}
        />
        <div aria-hidden="true" className="absolute inset-0 flex">
          {Array.from({ length: SEGMENTS }, (_, i) => (
            <span key={i} className={cn("flex-1", i < SEGMENTS - 1 && "border-r-2 border-[#0a0a0a]")} />
          ))}
        </div>
      </div>
    </div>
  );
}
