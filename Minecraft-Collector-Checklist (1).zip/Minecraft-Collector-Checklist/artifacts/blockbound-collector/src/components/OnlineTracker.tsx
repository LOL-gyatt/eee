import { useCallback, useEffect, useRef, useState } from 'react';
import { Radio, RefreshCw, Star, Trash2, Users } from 'lucide-react';
import { getXboxTrackerPresence, lookupXboxTrackerPlayer, type XboxPresenceResult, type XboxTrackerPlayer } from '@workspace/api-client-react';
import { cn } from '@/lib/utils';

const storageKey = 'blockbound_online_watchlist_v1';
const interval = 120_000;
const validPlayer = (value: unknown): value is XboxTrackerPlayer => {
  if (!value || typeof value !== 'object') return false;
  const p = value as XboxTrackerPlayer;
  return typeof p.xuid === 'string' && /^[0-9]{1,20}$/.test(p.xuid) &&
    typeof p.gamertag === 'string' && p.gamertag.length > 0 && p.gamertag.length <= 30;
};
type SavedPlayer = XboxTrackerPlayer & { favourite?: boolean };
function savedPlayers(): SavedPlayer[] {
  try {
    const data: unknown = JSON.parse(localStorage.getItem(storageKey) || '[]');
    return Array.isArray(data) ? data.filter(validPlayer).filter((p, i, all) => all.findIndex(q => q.xuid === p.xuid) === i).slice(0, 8).map(p => ({
      xuid: p.xuid, gamertag: p.gamertag, favourite: (p as SavedPlayer).favourite === true,
    })) : [];
  } catch { return []; }
}
function safeError(error: unknown): string {
  if (error instanceof Error && 'data' in error) {
    const data = error.data as { error?: unknown } | null;
    if (typeof data?.error === 'string') return data.error;
  }
  if (error instanceof Error && error.name === 'ResponseParseError') {
    return 'The tracker received an invalid server response. Reload the Replit preview and try again. (Invalid response)';
  }
  if (error instanceof Error && 'status' in error && typeof error.status === 'number') {
    return `The tracker request failed (HTTP ${error.status}). Reload the preview and try again; if it continues, report this status code.`;
  }
  if (error instanceof TypeError) {
    return 'The browser could not complete the tracker request. Reload the Replit preview and retry. If it continues, try opening the preview in a new tab. (Browser request failed)';
  }
  return 'The tracker could not complete this action. Reload the preview and retry. (Unexpected tracker error)';
}
const date = (value: string) => new Date(value).toLocaleString();
type Result = { value?: XboxPresenceResult; stale: boolean; error?: string; attemptedAt: string };

export function OnlineTracker({ active }: { active: boolean }) {
  const pollDelay = useRef(interval);
  const [now, setNow] = useState(Date.now);
  const [players, setPlayers] = useState(savedPlayers);
  const [favouritesOnly, setFavouritesOnly] = useState(false);
  const [results, setResults] = useState<Record<string, Result>>({});
  const [tag, setTag] = useState('');
  const [error, setError] = useState('');
  const [storageError, setStorageError] = useState('');
  const [loading, setLoading] = useState(false);
  const [adding, setAdding] = useState(false);
  const request = useRef<AbortController | null>(null);
  const lookup = useRef<AbortController | null>(null);
  const lastAttempt = useRef(0);
  const ids = players.map(p => p.xuid).sort().join(',');
  const favouriteCount = players.filter(p => p.favourite).length;
  const visiblePlayers = players.filter(p => !favouritesOnly || p.favourite)
    .sort((a, b) => Number(!!b.favourite) - Number(!!a.favourite));

  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(players)); setStorageError(''); }
    catch { setStorageError('Your browser could not save the watchlist. It will only last for this session.'); }
  }, [players]);

  const refresh = useCallback(async (force = false) => {
    if (!active || !ids || document.visibilityState !== 'visible' || request.current) return;
    if (!force && Date.now() - lastAttempt.current < pollDelay.current) return;
    const controller = new AbortController();
    request.current = controller;
    lastAttempt.current = Date.now();
    setLoading(true);
    try {
      const data = await getXboxTrackerPresence({ xuids: ids.split(',') }, { signal: controller.signal });
      if (controller.signal.aborted) return;
      pollDelay.current = Math.max(120, data.pollAfterSeconds) * 1000;
      setNow(Date.now());
      setResults(old => {
        const next = { ...old };
        for (const xuid of ids.split(',')) {
          const row = data.players.find(p => p.xuid === xuid);
          if (!row || row.status === 'unknown') {
            next[xuid] = { value: old[xuid]?.value, stale: true, error: row?.error || 'Public presence is unavailable or private.', attemptedAt: row?.checkedAt || new Date().toISOString() };
          } else next[xuid] = { value: row, stale: false, attemptedAt: row.checkedAt };
        }
        return next;
      });
      setError('');
    } catch (cause) {
      if (controller.signal.aborted) return;
      const message = safeError(cause);
      setError(message);
      setResults(old => {
        const next = { ...old };
        for (const xuid of ids.split(',')) next[xuid] = { value: old[xuid]?.value, stale: true, error: message, attemptedAt: new Date().toISOString() };
        return next;
      });
    } finally {
      if (request.current === controller) {
        request.current = null;
        if (!controller.signal.aborted) setLoading(false);
      }
    }
  }, [active, ids]);

  useEffect(() => {
    pollDelay.current = interval * Math.max(1, ids.split(',').length);
    setLoading(false);
    setAdding(false);
    if (!active) { lookup.current?.abort(); lookup.current = null; setAdding(false); return; }
    void refresh(true);
    const timer = window.setInterval(() => {
      setNow(Date.now());
      void refresh();
    }, 30_000);
    const visible = () => {
      if (document.visibilityState === 'visible') { setNow(Date.now()); void refresh(); }
      else { request.current?.abort(); request.current = null; setLoading(false); }
    };
    document.addEventListener('visibilitychange', visible);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', visible);
      request.current?.abort();
      request.current = null;
      lookup.current?.abort();
      lookup.current = null;
    };
  }, [active, refresh]);

  async function add(event: React.FormEvent) {
    event.preventDefault();
    if (adding || players.length >= 8) return;
    setError('');
    setAdding(true);
    const controller = new AbortController();
    lookup.current = controller;
    try {
      const player = await lookupXboxTrackerPlayer({ gamertag: tag.trim() }, { signal: controller.signal });
      if (controller.signal.aborted) return;
      if (!validPlayer(player)) {
        setError('The server did not return a valid Xbox profile. Reload the Replit preview and try again. (Invalid profile response)');
        return;
      }
      if (players.some(p => p.xuid === player.xuid)) { setError('This player is already on your watchlist.'); return; }
      setPlayers(old => old.length < 8 && !old.some(p => p.xuid === player.xuid) ? [...old, player] : old);
      setTag('');
    } catch (cause) { if (!controller.signal.aborted) setError(safeError(cause)); }
    finally {
      if (lookup.current === controller) { lookup.current = null; if (!controller.signal.aborted) setAdding(false); }
    }
  }

  if (!active) return null;
  return (
    <section id="panel-online" role="tabpanel" aria-labelledby="tab-online" className="space-y-6">
      <div className="bg-card border-2 border-border rounded-3xl p-5 md:p-7 space-y-4">
        <div className="flex items-center gap-3"><div className="mc-icon-tile"><Radio size={22} /></div><h2 className="text-2xl font-black">Online Tracker</h2></div>
        <p className="text-sm text-muted-foreground leading-relaxed">Follow up to 8 exact public Xbox gamertags, independent of Minecraft achievements. Public statuses come from OpenXBL, not Minecraft server activity. This is not Xbox sign-in or proof of ownership; privacy settings are respected.</p>
        <form onSubmit={add} className="flex flex-wrap gap-2">
          <input aria-label="Exact gamertag to track" value={tag} onChange={e => setTag(e.target.value)} maxLength={30} required placeholder="Exact Xbox gamertag"
            className="flex-1 min-w-[180px] bg-input border-2 border-border rounded-xl px-4 py-3 font-semibold focus:border-primary outline-none" />
          <button disabled={adding || players.length >= 8} className="bg-primary text-primary-foreground px-5 py-3 rounded-xl font-bold disabled:opacity-50">{adding ? 'Finding player…' : 'Add player'}</button>
        </form>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground max-w-2xl">Checks roughly every {Math.max(1, players.length) * 2} minutes only while this tab is open and the page is visible. Larger lists refresh less often to protect the shared Xbox allowance. Results older than 2 minutes are marked stale until the next successful check. No background tracking or server history. Watchlist saved on this browser. Refresh may return cached results; shared limits may delay updates.</p>
          <button type="button" disabled={loading || !players.length} onClick={() => void refresh(true)} className="flex items-center gap-2 bg-secondary border border-border rounded-xl px-4 py-2 font-bold disabled:opacity-50"><RefreshCw size={16} className={cn(loading && 'animate-spin')} />{loading ? 'Checking…' : 'Refresh'}</button>
        </div>
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        {storageError && <p role="alert" className="text-sm text-destructive">{storageError}</p>}
      </div>
      <div className="space-y-2">
        <div className="flex flex-wrap gap-2" aria-label="Friend filters">
          <button type="button" aria-pressed={!favouritesOnly} onClick={() => setFavouritesOnly(false)}
            className={cn('px-4 py-2 rounded-xl border font-bold', !favouritesOnly ? 'bg-primary text-primary-foreground border-primary' : 'bg-secondary border-border')}>All friends ({players.length})</button>
          <button type="button" aria-pressed={favouritesOnly} onClick={() => setFavouritesOnly(true)}
            className={cn('flex items-center gap-2 px-4 py-2 rounded-xl border font-bold', favouritesOnly ? 'bg-primary text-primary-foreground border-primary' : 'bg-secondary border-border')}><Star size={16} />Favourites ({favouriteCount})</button>
        </div>
        <p className="text-xs text-muted-foreground">Star accounts to keep favourite friends first. Saved in this browser only; this does not add friends or send requests on Xbox.</p>
      </div>
      {!players.length ? <div className="bg-card rounded-3xl border border-border py-12 text-center text-muted-foreground"><Users size={36} className="mx-auto mb-3 text-primary" /><p className="font-bold">Your watchlist is empty</p><p className="text-sm mt-1">Add a public gamertag to check their Xbox status.</p></div> :
        !visiblePlayers.length ? <div className="bg-card rounded-3xl border border-border py-12 text-center text-muted-foreground"><Star size={36} className="mx-auto mb-3 text-amber-400" /><p className="font-bold">No favourite friends yet</p><p className="text-sm mt-1">Choose All friends and star an Xbox account to add it here.</p></div> :
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" aria-live="polite">
          {visiblePlayers.map(player => {
            const result = results[player.xuid];
            const value = result?.value;
            const stale = result?.stale || !!value && (
              !Number.isFinite(Date.parse(value.checkedAt)) || now - Date.parse(value.checkedAt) >= interval);
            const status = stale ? 'unknown' : value?.status || 'unknown';
            return <article key={player.xuid} className="bg-card rounded-3xl border-2 border-border p-5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0"><h3 className="font-black text-lg break-words">{player.gamertag}</h3>
                  <p className={cn('font-bold capitalize flex items-center gap-2 mt-1', status === 'online' ? 'text-primary' : status === 'away' ? 'text-amber-400' : 'text-muted-foreground')}>
                    <span className="w-2.5 h-2.5 rounded-full bg-current" />{status}{stale ? ' · update needed' : ''}
                  </p>
                </div>
                <div className="flex gap-1 shrink-0">
                <button type="button" aria-pressed={!!player.favourite} aria-label={`${player.favourite ? 'Unfavourite' : 'Favourite'} ${player.gamertag}`}
                  onClick={() => setPlayers(old => old.map(p => p.xuid === player.xuid ? { ...p, favourite: !p.favourite } : p))}
                  className={cn('p-2 rounded-xl bg-secondary hover:text-amber-400', player.favourite && 'text-amber-400')}>
                  <Star size={18} fill={player.favourite ? 'currentColor' : 'none'} />
                </button>
                <button type="button" aria-label={`Remove ${player.gamertag}`} onClick={() => { setPlayers(old => old.filter(p => p.xuid !== player.xuid)); setResults(old => { const next = { ...old }; delete next[player.xuid]; return next; }); }}
                  className="p-2 rounded-xl bg-secondary hover:text-destructive"><Trash2 size={18} /></button>
                </div>
              </div>
              {stale && value && <p className="text-sm text-amber-400">Stale last result: {value.status}. Not a confirmed current status.</p>}
              <p className="text-sm text-muted-foreground">Xbox last seen: {value?.xboxLastSeenAt ? <time dateTime={value.xboxLastSeenAt}>{date(value.xboxLastSeenAt)}{stale ? ' (stale)' : ''}</time> : 'unavailable — Xbox did not report a timestamp.'}</p>
              <p className="text-xs text-muted-foreground">Source: public Xbox presence via OpenXBL.{value ? <> Last successful check: <time dateTime={value.checkedAt}>{date(value.checkedAt)}</time>.</> : ' No confirmed result yet.'} Busy is shown as online.</p>
              {result?.stale && <p className="text-xs text-muted-foreground">Last check attempt: <time dateTime={result.attemptedAt}>{date(result.attemptedAt)}</time>. Presence could not be confirmed.</p>}
              {result?.error && <p className="text-xs text-destructive">{result.error}</p>}
            </article>;
          })}
        </div>}
    </section>
  );
}
