import { useEffect, useRef, useState } from 'react';
import { Users, Link2, Copy, Check, LogOut, Send, ShieldAlert, Clock, DoorOpen, Plus, LoaderCircle, RefreshCw } from 'lucide-react';
import { useFriendChat, inviteUrl, errorMessage } from '@/hooks/use-friend-chat';
import { cn } from '@/lib/utils';

const KEY_RE = /^[A-Za-z0-9_-]{43}$/;
const inputClass = 'w-full bg-input border-2 border-border px-4 py-3 font-semibold outline-none focus:border-primary placeholder:text-muted-foreground';
const btn = 'inline-flex items-center justify-center gap-2 border-2 px-4 py-2.5 text-sm disabled:opacity-50 disabled:cursor-not-allowed';
const btnPrimary = cn(btn, 'bg-primary text-primary-foreground border-primary');
const btnStone = cn(btn, 'bg-secondary text-secondary-foreground border-border');

function parseInvite(text: string): string | null {
  const t = text.trim();
  if (KEY_RE.test(t)) return t;
  const m = t.match(/#join=([A-Za-z0-9_-]{43})\s*$/);
  return m ? m[1] : null;
}
const timeOf = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
function remaining(iso: string | null) {
  if (!iso) return '';
  const ms = Date.parse(iso) - Date.now();
  if (ms <= 0) return 'expiring';
  const h = Math.floor(ms / 3_600_000), m = Math.floor((ms % 3_600_000) / 60_000);
  return h ? `${h}h ${m}m left` : `${m}m left`;
}

function Disclosure() {
  return (
    <div className="flex items-start gap-3 border-2 border-accent/40 bg-accent/5 p-4 text-sm leading-relaxed text-muted-foreground">
      <ShieldAlert size={20} className="mt-0.5 shrink-0 text-accent" />
      <p><strong className="text-foreground">Website chat, not Xbox messages.</strong> No sign-in: anyone holding the invite link can join and read the room, so share it only with friends. Nicknames are not verified and are not Xbox gamertags. Rooms expire 24 hours after creation, keep the latest 200 messages, and close when everyone leaves.</p>
    </div>
  );
}

function Lobby({ chat }: { chat: ReturnType<typeof useFriendChat> }) {
  const [nickname, setNickname] = useState('');
  const [invite, setInvite] = useState(chat.pendingInvite ? inviteUrl(chat.pendingInvite) : '');
  const [error, setError] = useState('');
  const key = chat.pendingInvite ?? parseInvite(invite);
  const nickOk = nickname.trim().length >= 1 && nickname.trim().length <= 24;

  const run = async (fn: () => Promise<void>, fallback: string) => {
    setError('');
    try { await fn(); } catch (e) { setError(errorMessage(e, fallback)); }
  };

  return (
    <div className="grid gap-5 md:grid-cols-[1fr_1fr]">
      <form className="bg-card border-2 border-border p-5 md:p-6 space-y-4 md:col-span-2" onSubmit={e => e.preventDefault()}>
        <label htmlFor="friend-nickname" className="block text-xs uppercase text-muted-foreground">Your nickname in this room</label>
        <input id="friend-nickname" data-testid="input-friend-nickname" value={nickname} maxLength={24} onChange={e => setNickname(e.target.value)} placeholder="e.g. Pickaxe Pat" className={inputClass} autoComplete="off" />
        <p className="text-xs text-muted-foreground">1–24 characters. Others in the room see this name.</p>
      </form>

      {chat.pendingInvite ? (
        <div className="bg-card border-2 border-primary p-5 md:p-6 space-y-4 md:col-span-2">
          <div className="flex items-center gap-3"><DoorOpen className="text-primary" /><h3 className="text-lg">You were invited to a room</h3></div>
          <p className="text-sm text-muted-foreground">Pick a nickname above, then join. The invite was removed from your address bar.</p>
          <div className="flex flex-wrap gap-2">
            <button type="button" data-testid="button-join-invite" disabled={!nickOk || chat.busy !== null} className={btnPrimary}
              onClick={() => run(() => chat.join(chat.pendingInvite!, nickname), 'Could not join this room.')}>
              {chat.busy === 'join' ? <LoaderCircle size={16} className="animate-spin" /> : <DoorOpen size={16} />} Join room
            </button>
            <button type="button" className={btnStone} onClick={() => { chat.setPendingInvite(null); setInvite(''); }}>Dismiss invite</button>
          </div>
        </div>
      ) : (<>
        <div className="bg-card border-2 border-border p-5 md:p-6 space-y-4">
          <div className="flex items-center gap-3"><Plus className="text-primary" /><h3 className="text-lg">Start a room</h3></div>
          <p className="text-sm text-muted-foreground">Creates a private room and a secret invite link to send to friends.</p>
          <button type="button" data-testid="button-create-room" disabled={!nickOk || chat.busy !== null} className={btnPrimary}
            onClick={() => run(() => chat.create(nickname), 'Could not create a room.')}>
            {chat.busy === 'create' ? <LoaderCircle size={16} className="animate-spin" /> : <Plus size={16} />} Create room
          </button>
        </div>
        <div className="bg-card border-2 border-border p-5 md:p-6 space-y-4">
          <div className="flex items-center gap-3"><Link2 className="text-primary" /><h3 className="text-lg">Join with a link</h3></div>
          <label htmlFor="friend-invite" className="sr-only">Invite link</label>
          <input id="friend-invite" data-testid="input-friend-invite" value={invite} onChange={e => setInvite(e.target.value)} placeholder="Paste invite link" className={inputClass} autoComplete="off" spellCheck={false} />
          {invite && !key && <p className="text-xs text-destructive">That doesn't look like a Blockbound invite link.</p>}
          <button type="button" data-testid="button-join-room" disabled={!nickOk || !key || chat.busy !== null} className={btnStone}
            onClick={() => run(() => chat.join(key!, nickname), 'Could not join this room.')}>
            {chat.busy === 'join' ? <LoaderCircle size={16} className="animate-spin" /> : <DoorOpen size={16} />} Join room
          </button>
        </div>
      </>)}
      {error && <p role="alert" className="md:col-span-2 border-2 border-destructive/50 bg-destructive/10 p-3 text-sm">{error}</p>}
    </div>
  );
}

function Room({ chat }: { chat: ReturnType<typeof useFriendChat> }) {
  const session = chat.session!;
  const [draft, setDraft] = useState('');
  const [sendError, setSendError] = useState('');
  const [copied, setCopied] = useState<'ok' | 'fail' | null>(null);
  const [confirmLeave, setConfirmLeave] = useState(false);
  const log = useRef<HTMLDivElement>(null);
  const linkRef = useRef<HTMLInputElement>(null);
  const link = inviteUrl(session.roomKey);
  const self = session.participantId;

  useEffect(() => { if (log.current) log.current.scrollTop = log.current.scrollHeight; }, [chat.messages.length]);

  const copy = async () => {
    try { await navigator.clipboard.writeText(link); setCopied('ok'); }
    catch { setCopied('fail'); requestAnimationFrame(() => linkRef.current?.select()); }
  };
  const submit = async () => {
    const body = draft.trim();
    if (!body || chat.busy === 'send') return;
    setSendError('');
    try { await chat.send(body); setDraft(''); }
    catch (e) { setSendError(errorMessage(e, 'Message not sent. Your text is kept; try again.')); }
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_260px]">
      <div className="bg-card border-2 border-border flex flex-col min-h-[460px]">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-border px-4 py-3">
          <p className="text-sm"><span className="text-muted-foreground">You are </span><strong data-testid="text-friend-self">{session.nickname}</strong></p>
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Clock size={14} />{remaining(chat.expiresAt ?? session.expiresAt)}</span>
        </div>
        <div ref={log} role="log" aria-live="polite" aria-label="Room messages" className="flex-1 overflow-y-auto p-4 space-y-3 max-h-[52vh] bg-[hsl(30_6%_12%)]">
          {!chat.loaded && !chat.pollError ? (
            <div className="space-y-3" aria-label="Loading messages">{[60, 40, 70].map(w => <div key={w} className="h-12 bg-secondary/60 animate-pulse" style={{ width: `${w}%` }} />)}</div>
          ) : chat.messages.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground"><Users size={32} className="mx-auto mb-3 text-primary" /><p className="text-foreground">No messages yet</p><p className="text-sm mt-1">Copy the invite link and send it to a friend, then say hi.</p></div>
          ) : chat.messages.map(m => (
            <article key={m.id} data-testid={`friend-message-${m.id}`} className={cn('max-w-[88%] border-2 px-3 py-2', m.participantId === self ? 'ml-auto border-primary/60 bg-primary/10' : 'border-border bg-card')}>
              <div className="flex items-baseline gap-2 text-xs mb-1">
                <span className={cn('font-bold', m.participantId === self ? 'text-primary' : 'text-accent')}>{m.nickname}{m.participantId === self ? ' (you)' : ''}</span>
                <time dateTime={m.createdAt} className="text-muted-foreground">{timeOf(m.createdAt)}</time>
              </div>
              <p className="whitespace-pre-wrap break-words text-sm leading-relaxed">{m.body}</p>
            </article>
          ))}
        </div>
        {chat.pollError && (
          <div role="alert" className="flex items-center justify-between gap-2 border-t-2 border-destructive/50 bg-destructive/10 px-4 py-2 text-sm">
            <span>{chat.pollError}</span><button type="button" className={btnStone} onClick={() => void chat.retry()}><RefreshCw size={14} />Retry</button>
          </div>
        )}
        <form className="border-t-2 border-border p-3 space-y-2" onSubmit={e => { e.preventDefault(); void submit(); }}>
          <label htmlFor="friend-message" className="sr-only">Message</label>
          <div className="flex gap-2">
            <textarea id="friend-message" data-testid="input-friend-message" rows={2} maxLength={500} value={draft}
              onChange={e => { setDraft(e.target.value); chat.draftChanged(); }}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void submit(); } }}
              placeholder="Message your friends (Enter to send)" className={cn(inputClass, 'resize-none py-2')} />
            <button type="submit" data-testid="button-send-friend" aria-label="Send message" disabled={!draft.trim() || chat.busy === 'send'} className={cn(btnPrimary, 'px-4')}>
              {chat.busy === 'send' ? <LoaderCircle size={18} className="animate-spin" /> : <Send size={18} />}
            </button>
          </div>
          <div className="flex justify-between text-xs text-muted-foreground"><span role={sendError ? 'alert' : undefined} className={cn(sendError && 'text-destructive')}>{sendError}</span><span>{draft.length}/500</span></div>
        </form>
      </div>

      <aside className="space-y-5">
        <div className="bg-card border-2 border-border p-4 space-y-3">
          <h3 className="text-sm flex items-center gap-2"><Link2 size={16} className="text-primary" />Invite link</h3>
          <label htmlFor="friend-link" className="sr-only">Invite link</label>
          <input id="friend-link" ref={linkRef} readOnly value={link} onFocus={e => e.currentTarget.select()} className={cn(inputClass, 'text-xs py-2')} />
          <button type="button" data-testid="button-copy-invite" onClick={copy} className={cn(btnPrimary, 'w-full')}>{copied === 'ok' ? <Check size={16} /> : <Copy size={16} />}{copied === 'ok' ? 'Copied' : 'Copy invite'}</button>
          {copied === 'fail' && <p role="status" className="text-xs text-accent">Couldn't copy automatically. The link is selected: press Ctrl+C (or long-press to copy).</p>}
          <p className="text-xs text-muted-foreground">Anyone with this link can join and read.</p>
        </div>
        <div className="bg-card border-2 border-border p-4 space-y-3">
          <h3 className="text-sm flex items-center gap-2"><Users size={16} className="text-primary" />In room {chat.participants.length}/{chat.maxParticipants}</h3>
          <ul className="space-y-1.5 text-sm">
            {chat.participants.map(p => <li key={p.participantId} className="flex items-center gap-2"><span className="w-2 h-2 bg-primary" aria-hidden="true" />{p.nickname}{p.participantId === self && <span className="text-muted-foreground text-xs">(you)</span>}</li>)}
          </ul>
        </div>
        {confirmLeave ? (
          <div className="bg-card border-2 border-destructive p-4 space-y-3">
            <p className="text-sm">Leave this room? You'll need the invite link to rejoin under a new session.</p>
            <div className="flex gap-2">
              <button type="button" data-testid="button-confirm-leave" disabled={chat.busy === 'leave'} onClick={() => void chat.leave()} className={cn(btn, 'bg-destructive text-destructive-foreground border-destructive flex-1')}>Leave</button>
              <button type="button" onClick={() => setConfirmLeave(false)} className={cn(btnStone, 'flex-1')}>Stay</button>
            </div>
          </div>
        ) : (
          <button type="button" data-testid="button-leave-room" onClick={() => setConfirmLeave(true)} className={cn(btnStone, 'w-full hover:bg-destructive hover:text-destructive-foreground')}><LogOut size={16} />Leave room</button>
        )}
      </aside>
    </div>
  );
}

export function FriendChat({ active }: { active: boolean }) {
  const chat = useFriendChat(active);
  return (
    <section id="panel-friends" role="tabpanel" aria-labelledby="tab-friends" hidden={!active} className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="mc-icon-tile"><Users size={24} /></div>
        <div>
          <h2 className="text-2xl">Friend Chat</h2>
          <p className="text-sm text-muted-foreground">Private invite-only rooms. No account needed.</p>
        </div>
      </div>
      <Disclosure />
      {chat.ended && !chat.session && <p role="status" className="border-2 border-border bg-card p-3 text-sm">{chat.ended}</p>}
      {chat.session ? <Room chat={chat} /> : <Lobby chat={chat} />}
    </section>
  );
}
