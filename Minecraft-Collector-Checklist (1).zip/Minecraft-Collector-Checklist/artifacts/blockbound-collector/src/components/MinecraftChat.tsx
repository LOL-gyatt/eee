import { useEffect, useRef } from 'react';
import { useForm } from 'react-hook-form';
import { Bot, Send, Sparkles, Square, Trash2, RotateCcw, ShieldCheck, LoaderCircle } from 'lucide-react';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useMinecraftChat } from '@/hooks/use-minecraft-chat';
import { cn } from '@/lib/utils';

const suggestions = [
  'How can I earn On A Rail in Bedrock?',
  'Where should I look for armor trims?',
  'Help me survive my first night.',
];
const buttonClass = 'inline-flex items-center justify-center gap-2 rounded-xl border-2 border-border bg-secondary px-4 py-2.5 text-sm font-bold transition-colors hover:border-primary/50 disabled:cursor-not-allowed disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-primary focus-visible:outline-offset-2';

export function MinecraftChat({ active }: { active: boolean }) {
  const chat = useMinecraftChat(active);
  const form = useForm<{ question: string }>({ defaultValues: { question: '' } });
  const question = form.watch('question');
  const log = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (active && log.current) log.current.scrollTop = log.current.scrollHeight;
  }, [active, chat.messages, chat.pending, chat.lastQuestion, chat.error]);

  return (
    <section id="panel-ai" role="tabpanel" aria-labelledby="tab-ai" hidden={!active} className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="mc-icon-tile"><Bot size={24} /></div>
          <div>
            <h2 className="text-2xl font-black">Minecraft AI</h2>
            <p className="text-sm text-muted-foreground">Your next adventure, one question away.</p>
          </div>
        </div>
        <span data-testid="text-ai-provider" className="rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 text-xs font-bold text-primary">Replit AI · GPT-5.4 mini</span>
      </div>

      <div className="rounded-2xl border border-primary/25 bg-primary/5 p-4 text-sm leading-relaxed text-muted-foreground">
        <div className="flex items-start gap-2">
          <ShieldCheck size={19} className="mt-0.5 shrink-0 text-primary" />
          <p><strong className="text-foreground">Real AI, powered by Replit AI Integrations.</strong> No personal API key needed. Questions and recent messages from this chat box are sent to the AI service; Replit AI credits apply.</p>
        </div>
        <p className="mt-2 pl-7" data-testid="text-ai-privacy">Chat history means only messages you type here — we do not fetch your Replit chats or send your Xbox profile automatically. History stays in this page's memory and is cleared on reload. Avoid sharing personal information. AI can be wrong and has no live patch or web access.</p>
      </div>

      <div className="overflow-hidden rounded-3xl border-2 border-border bg-card shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-4">
          <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground" data-testid="text-ai-history">Page-session chat · last 4 turns used for context</span>
          <button type="button" onClick={() => { chat.clear(); form.reset(); }} disabled={!chat.messages.length && !chat.lastQuestion && !question}
            className={buttonClass} data-testid="button-clear-ai-chat"><Trash2 size={16} /> Clear chat</button>
        </div>
        <div ref={log} role="log" aria-label="Minecraft chat messages" aria-live="polite" aria-relevant="additions" className="max-h-[520px] min-h-[240px] space-y-5 overflow-y-auto p-5 md:p-7">
          {!chat.messages.length && !chat.lastQuestion && (
            <div className="mx-auto flex max-w-xl flex-col items-center py-5 text-center">
              <Sparkles className="mb-3 text-primary" size={30} />
              <h3 className="text-xl font-extrabold">What are you working on?</h3>
              <p className="mb-5 mt-2 text-sm leading-relaxed text-muted-foreground">Ask about Bedrock achievements, finding collectibles, crafting or survival. Add your edition and version for more specific advice.</p>
              <div className="flex flex-wrap justify-center gap-2">
                {suggestions.map((prompt, index) => (
                  <button type="button" key={prompt} disabled={chat.pending} onClick={() => { form.setValue('question', prompt, { shouldValidate: true }); form.setFocus('question'); }}
                    className={cn(buttonClass, 'bg-background text-left')} data-testid={`button-ai-prompt-${index}`}>{prompt}</button>
                ))}
              </div>
            </div>
          )}
          {chat.messages.map((message, index) => (
            <article key={index} data-testid={`message-ai-${index}`} className={cn('max-w-[95%] rounded-2xl border p-4 md:max-w-[85%]', message.role === 'user' ? 'ml-auto border-primary/30 bg-primary/10' : 'border-border bg-background/70')}>
              <p className={cn('mb-2 text-xs font-black uppercase tracking-wider', message.role === 'user' ? 'text-primary' : 'text-muted-foreground')}>{message.role === 'user' ? 'You' : 'Blockbound AI'}</p>
              <p className="whitespace-pre-wrap break-words text-sm leading-relaxed [overflow-wrap:anywhere]">{message.content}</p>
            </article>
          ))}
          {chat.lastQuestion && (
            <article className="ml-auto max-w-[95%] rounded-2xl border border-primary/30 bg-primary/10 p-4 md:max-w-[85%]" data-testid="message-ai-current-question">
              <p className="mb-2 text-xs font-black uppercase tracking-wider text-primary">You{!chat.pending && chat.error ? ' · not answered' : ''}</p>
              <p className="whitespace-pre-wrap break-words text-sm leading-relaxed [overflow-wrap:anywhere]">{chat.lastQuestion}</p>
            </article>
          )}
          {chat.pending && <div role="status" data-testid="status-ai-thinking" className="flex items-center gap-2 text-sm font-bold text-primary"><LoaderCircle size={18} className="animate-spin" /> Blockbound is thinking…</div>}
          {chat.error && (
            <div role="alert" data-testid="status-ai-error" className="rounded-xl border border-destructive/40 bg-destructive/10 p-4 text-sm">
              <p>{chat.error}</p>
              {chat.lastQuestion && <button type="button" disabled={chat.pending} onClick={chat.retry} className={cn(buttonClass, 'mt-3')} data-testid="button-retry-ai"><RotateCcw size={16} /> Retry question</button>}
            </div>
          )}
          {chat.notice && <p role="status" data-testid="status-ai-notice" className="text-sm text-muted-foreground">{chat.notice}</p>}
        </div>
        <div className="border-t border-border bg-background/30 p-5">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(values => { if (chat.send(values.question)) form.reset(); })} className="space-y-3">
              <FormField control={form.control} name="question" rules={{
                validate: value => !!value.trim() || 'Type a Minecraft question first.',
                maxLength: { value: chat.maxQuestion, message: `Maximum ${chat.maxQuestion} characters.` },
              }} render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-bold">Ask a Minecraft question</FormLabel>
                  <FormControl>
                    <textarea {...field} rows={3} maxLength={chat.maxQuestion} disabled={chat.pending} placeholder="For example: How do I cure a zombie villager in Bedrock?"
                      data-testid="input-ai-question" className="w-full resize-y rounded-xl border-2 border-border bg-input px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-primary disabled:opacity-60"
                      onKeyDown={event => {
                        if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
                          event.preventDefault();
                          event.currentTarget.form?.requestSubmit();
                        }
                      }} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs text-muted-foreground" data-testid="text-ai-question-length">{question.length}/{chat.maxQuestion} · Enter to send, Shift+Enter for a new line</span>
                {chat.pending ? (
                  <button type="button" onClick={() => chat.stop()} className={buttonClass} data-testid="button-stop-ai"><Square size={15} /> Stop request</button>
                ) : (
                  <button type="submit" disabled={!question.trim()} className={cn(buttonClass, 'border-primary bg-primary text-primary-foreground hover:bg-primary/90')} data-testid="button-send-ai"><Send size={16} /> Send question</button>
                )}
              </div>
            </form>
          </Form>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Only completed turns are sent as context. Older turns are omitted; at most 20 turns are displayed. Stopping or leaving this tab cancels the pending request, but credits may already have been used. Clear chat does not delete any AI-provider records.</p>
        </div>
      </div>
    </section>
  );
}