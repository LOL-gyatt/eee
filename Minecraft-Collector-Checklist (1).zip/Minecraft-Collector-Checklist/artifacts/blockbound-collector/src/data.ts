import { achievements } from './achievements';

export type Category = 'Armor Trim' | 'Wolf' | 'Music Disc' | 'Pottery Sherd' | 'Banner Pattern' | 'Goat Horn' | 'Achievement';
export type Rarity = 'Common' | 'Rare' | 'Epic';

export interface Collectible {
  id: string;
  name: string;
  category: Category;
  rarity?: Rarity;
  location: string;
  tip: string;
  description?: string;
  requirement?: string;
  gamerscore?: number;
  image?: string;
}

export const collectibles: Collectible[] = [
  // Armor Trims
  { id: 'trim-sentry', name: 'Sentry Armor Trim', category: 'Armor Trim', rarity: 'Common', location: 'Pillager Outpost', tip: 'Check the chest at the top of the outpost.' },
  { id: 'trim-dune', name: 'Dune Armor Trim', category: 'Armor Trim', rarity: 'Common', location: 'Desert Temple', tip: 'Look in the hidden chests at the bottom of the temple.' },
  { id: 'trim-coast', name: 'Coast Armor Trim', category: 'Armor Trim', rarity: 'Common', location: 'Shipwreck', tip: 'Search all treasure chests in the sunken vessel.' },
  { id: 'trim-wild', name: 'Wild Armor Trim', category: 'Armor Trim', rarity: 'Common', location: 'Jungle Temple', tip: 'Disarm the traps before opening the chests.' },
  { id: 'trim-tide', name: 'Tide Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Ocean Monument', tip: 'Defeat the Elder Guardian; it drops this trim.' },
  { id: 'trim-ward', name: 'Ward Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Ancient City', tip: 'Sneak carefully around the sculk sensors to loot chests.' },
  { id: 'trim-silence', name: 'Silence Armor Trim', category: 'Armor Trim', rarity: 'Epic', location: 'Ancient City', tip: 'Extremely rare find in the central structure chests.' },
  { id: 'trim-vex', name: 'Vex Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Woodland Mansion', tip: 'Explore the upper floor rooms carefully.' },
  { id: 'trim-rib', name: 'Rib Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Nether Fortress', tip: 'Loot the chests scattered along the corridors.' },
  { id: 'trim-snout', name: 'Snout Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Bastion Remnant', tip: 'Found in chests; beware the Piglin Brutes.' },
  { id: 'trim-eye', name: 'Eye Armor Trim', category: 'Armor Trim', rarity: 'Common', location: 'Stronghold', tip: 'Check library and corridor chests before the End portal.' },
  { id: 'trim-spire', name: 'Spire Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'End City', tip: 'Climb the towers; watch out for Shulkers.' },
  { id: 'trim-wayfinder', name: 'Wayfinder Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Trail Ruins', tip: 'Use a brush on suspicious gravel.' },
  { id: 'trim-raiser', name: 'Raiser Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Trail Ruins', tip: 'Keep brushing suspicious gravel in the ruins.' },
  { id: 'trim-shaper', name: 'Shaper Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Trail Ruins', tip: 'Found by carefully excavating the ancient paths.' },
  { id: 'trim-host', name: 'Host Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel blocks around the central structure.' },
  { id: 'trim-flow', name: 'Flow Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Trial Chambers', tip: 'Unlock vault blocks with trial keys.' },
  { id: 'trim-bolt', name: 'Bolt Armor Trim', category: 'Armor Trim', rarity: 'Rare', location: 'Trial Chambers', tip: 'Defeat the breeze and use trial keys on vaults.' },
  
  // Wolf Variants
  { id: 'wolf-pale', name: 'Pale Wolf', category: 'Wolf', rarity: 'Common', location: 'Taiga', tip: 'The classic wolf; found wandering among the spruce trees.' },
  { id: 'wolf-woods', name: 'Woods Wolf', category: 'Wolf', rarity: 'Common', location: 'Forest', tip: 'Found blending into the oak and birch woods.' },
  { id: 'wolf-ashen', name: 'Ashen Wolf', category: 'Wolf', rarity: 'Common', location: 'Snowy Taiga', tip: 'Look for this grey wolf in the cold snowy forests.' },
  { id: 'wolf-black', name: 'Black Wolf', category: 'Wolf', rarity: 'Common', location: 'Old Growth Pine Taiga', tip: 'Striking black fur, hides well in the dark pines.' },
  { id: 'wolf-chestnut', name: 'Chestnut Wolf', category: 'Wolf', rarity: 'Common', location: 'Old Growth Spruce Taiga', tip: 'A warm brown variant roaming the towering spruce.' },
  { id: 'wolf-rusty', name: 'Rusty Wolf', category: 'Wolf', rarity: 'Common', location: 'Sparse Jungle', tip: 'Roams the edges of the dense jungle terrain.' },
  { id: 'wolf-spotted', name: 'Spotted Wolf', category: 'Wolf', rarity: 'Common', location: 'Savanna Plateau', tip: 'Often found resting in the shade of acacia trees.' },
  { id: 'wolf-striped', name: 'Striped Wolf', category: 'Wolf', rarity: 'Common', location: 'Wooded Badlands', tip: 'A rugged variant adapted to the terracotta hills.' },
  { id: 'wolf-snowy', name: 'Snowy Wolf', category: 'Wolf', rarity: 'Rare', location: 'Grove', tip: 'Wanders alone in the pristine mountain snow.' },

  // Music Discs
  { id: 'disc-13', name: 'Music Disc - 13', category: 'Music Disc', rarity: 'Common', location: 'Dungeons, Woodland Mansions', tip: 'Found in chest loot.' },
  { id: 'disc-cat', name: 'Music Disc - Cat', category: 'Music Disc', rarity: 'Common', location: 'Dungeons, Woodland Mansions', tip: 'Found in chest loot.' },
  { id: 'disc-blocks', name: 'Music Disc - Blocks', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-chirp', name: 'Music Disc - Chirp', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-far', name: 'Music Disc - Far', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-mall', name: 'Music Disc - Mall', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-mellohi', name: 'Music Disc - Mellohi', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-stal', name: 'Music Disc - Stal', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-strad', name: 'Music Disc - Strad', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-ward', name: 'Music Disc - Ward', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-11', name: 'Music Disc - 11', category: 'Music Disc', rarity: 'Rare', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-wait', name: 'Music Disc - Wait', category: 'Music Disc', rarity: 'Common', location: 'Creeper Drop', tip: 'Dropped when a Creeper is killed by a Skeleton.' },
  { id: 'disc-otherside', name: 'Music Disc - otherside', category: 'Music Disc', rarity: 'Rare', location: 'Strongholds, Dungeons, Ancient Cities', tip: 'Found in various rare chest loot.' },
  { id: 'disc-5', name: 'Music Disc - 5', category: 'Music Disc', rarity: 'Epic', location: 'Ancient City', tip: 'Crafted using 9 Disc Fragments found in Ancient Cities.' },
  { id: 'disc-pigstep', name: 'Music Disc - Pigstep', category: 'Music Disc', rarity: 'Epic', location: 'Bastion Remnant', tip: 'Rare find in Bastion chests.' },
  { id: 'disc-relic', name: 'Music Disc - Relic', category: 'Music Disc', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel in Trail Ruins.' },
  { id: 'disc-creator', name: 'Music Disc - Creator', category: 'Music Disc', rarity: 'Rare', location: 'Trial Chambers', tip: 'Found in Ominous Vaults.' },
  { id: 'disc-creator-box', name: 'Music Disc - Creator (Music Box)', category: 'Music Disc', rarity: 'Rare', location: 'Trial Chambers', tip: 'Found in Vaults.' },
  { id: 'disc-precipice', name: 'Music Disc - Precipice', category: 'Music Disc', rarity: 'Rare', location: 'Trial Chambers', tip: 'Found in standard Vaults.' },
  { id: 'disc-lava-chicken', name: 'Music Disc - Lava Chicken', category: 'Music Disc', rarity: 'Rare', location: 'Chicken Jockey Drop', tip: 'Defeat a baby zombie riding a chicken to obtain this disc.' },
  { id: 'disc-tears', name: 'Music Disc - Tears', category: 'Music Disc', rarity: 'Rare', location: 'Ghast Drop', tip: 'Kill a ghast with a fireball that you deflect back at it.' },
  // Item details and original sprite: https://minecraft.wiki/w/Music_Disc_Bounce
  { id: 'disc-bounce', name: 'Music Disc - Bounce', category: 'Music Disc', rarity: 'Rare', location: 'Mineshafts in Sulfur Caves', tip: 'Search chest minecarts in mineshafts within sulfur caves. Plays Bounce by fingerspit in a jukebox.' },

  // Pottery Sherds
  { id: 'sherd-angler', name: 'Angler Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Warm Ocean Ruins', tip: 'Brush suspicious sand.' },
  { id: 'sherd-archer', name: 'Archer Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Desert Temple', tip: 'Brush suspicious sand.' },
  { id: 'sherd-arms-up', name: 'Arms Up Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Desert Well', tip: 'Brush suspicious sand.' },
  { id: 'sherd-blade', name: 'Blade Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-brewer', name: 'Brewer Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Desert Well', tip: 'Brush suspicious sand.' },
  { id: 'sherd-burn', name: 'Burn Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-danger', name: 'Danger Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-explorer', name: 'Explorer Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-friend', name: 'Friend Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-heart', name: 'Heart Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-heartbreak', name: 'Heartbreak Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-howl', name: 'Howl Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-miner', name: 'Miner Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Desert Temple', tip: 'Brush suspicious sand.' },
  { id: 'sherd-mourner', name: 'Mourner Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-plenty', name: 'Plenty Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-prize', name: 'Prize Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Desert Temple', tip: 'Brush suspicious sand.' },
  { id: 'sherd-sheaf', name: 'Sheaf Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Trail Ruins', tip: 'Brush suspicious gravel.' },
  { id: 'sherd-shelter', name: 'Shelter Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Warm Ocean Ruins', tip: 'Brush suspicious sand.' },
  { id: 'sherd-skull', name: 'Skull Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Desert Temple', tip: 'Brush suspicious sand.' },
  { id: 'sherd-snort', name: 'Snort Pottery Sherd', category: 'Pottery Sherd', rarity: 'Rare', location: 'Warm Ocean Ruins', tip: 'Brush suspicious sand.' },
  
  // Banner Patterns
  { id: 'banner-flower', name: 'Flower Charge', category: 'Banner Pattern', rarity: 'Common', location: 'Crafting', tip: 'Craft using an Oxeye Daisy.' },
  { id: 'banner-creeper', name: 'Creeper Charge', category: 'Banner Pattern', rarity: 'Epic', location: 'Crafting', tip: 'Craft using a Creeper Head.' },
  { id: 'banner-skull', name: 'Skull Charge', category: 'Banner Pattern', rarity: 'Epic', location: 'Crafting', tip: 'Craft using a Wither Skeleton Skull.' },
  { id: 'banner-thing', name: 'Thing', category: 'Banner Pattern', rarity: 'Epic', location: 'Crafting', tip: 'Craft using an Enchanted Golden Apple.' },
  { id: 'banner-snout', name: 'Snout', category: 'Banner Pattern', rarity: 'Rare', location: 'Bastion Remnant', tip: 'Found in Bastion chests.' },
  { id: 'banner-globe', name: 'Globe', category: 'Banner Pattern', rarity: 'Rare', location: 'Trading', tip: 'Trade with a Master-level Cartographer villager.' },
  { id: 'banner-flow', name: 'Flow', category: 'Banner Pattern', rarity: 'Rare', location: 'Trial Chambers', tip: 'Found in Ominous Vaults.' },
  { id: 'banner-guster', name: 'Guster', category: 'Banner Pattern', rarity: 'Rare', location: 'Trial Chambers', tip: 'Found in Ominous Vaults.' },

  // Goat Horns
  { id: 'horn-ponder', name: 'Ponder Goat Horn', category: 'Goat Horn', rarity: 'Common', location: 'Mountains', tip: 'Dropped when a Goat rams coal ore, emerald ore, iron ore, log, packed ice, or stone.' },
  { id: 'horn-sing', name: 'Sing Goat Horn', category: 'Goat Horn', rarity: 'Common', location: 'Mountains', tip: 'Dropped when a Goat rams solid blocks.' },
  { id: 'horn-seek', name: 'Seek Goat Horn', category: 'Goat Horn', rarity: 'Common', location: 'Mountains', tip: 'Dropped when a Goat rams solid blocks.' },
  { id: 'horn-feel', name: 'Feel Goat Horn', category: 'Goat Horn', rarity: 'Common', location: 'Mountains', tip: 'Dropped when a Goat rams solid blocks.' },
  { id: 'horn-admire', name: 'Admire Goat Horn', category: 'Goat Horn', rarity: 'Rare', location: 'Mountains', tip: 'Dropped by a Screaming Goat when it rams solid blocks.' },
  { id: 'horn-call', name: 'Call Goat Horn', category: 'Goat Horn', rarity: 'Rare', location: 'Mountains', tip: 'Dropped by a Screaming Goat when it rams solid blocks.' },
  { id: 'horn-yearn', name: 'Yearn Goat Horn', category: 'Goat Horn', rarity: 'Rare', location: 'Mountains', tip: 'Dropped by a Screaming Goat when it rams solid blocks.' },
  { id: 'horn-dream', name: 'Dream Goat Horn', category: 'Goat Horn', rarity: 'Rare', location: 'Mountains', tip: 'Dropped by a Screaming Goat when it rams solid blocks.' },
  ...achievements
];