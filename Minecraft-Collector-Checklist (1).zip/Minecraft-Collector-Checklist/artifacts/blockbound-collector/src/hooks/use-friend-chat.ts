import { useCallback, useEffect, useRef, useState } from 'react';
import {
  createFriendRoom, joinFriendRoom, listFriendMessages, sendFriendMessage, leaveFriendRoom,
  type FriendMessage, type FriendParticipant, type FriendRoomSession,
} from '@workspace/api-client-react';

const storageKey = 'blockbound_friend_chat_session';
const KEY_RE = /^[A-Za-z0-9_-]{43}$/;
const POLL_MS = 4000;

function loadSession(): FriendRoomSession | null {
  try {
    const v = JSON.parse(localStorage.getItem(storageKey) || 'null');
    if (v && KEY_RE.test(v.roomKey) && KEY_RE.test(v.token) && typeof v.nickname === 'string' && Date.parse(v.expiresAt) > Date.now()) return v;
  } catch { /* ignore */ }
  localStorage.removeItem(storageKey);
  return null;
}

/** Reads `#join=<key>` once, then strips it from the address bar so it isn't left in history. */
function takeInviteFromHash(): string | null {
  const m = window.location.hash.match(/^#join=([A-Za-z0-9_-]{43})$/);
  if (!m) return null;
  history.replaceState(null, '', window.location.pathname + window.location.search);
  return m[1];
}
export const hasInviteInHash = () => /^#join=[A-Za-z0-9_-]{43}$/.test(window.location.hash);
export const inviteUrl = (roomKey: string) => `${window.location.origin}${import.meta.env.BASE_URL}#join=${roomKey}`;

export function errorMessage(error: unknown, fallback: string): string {
  if (error && typeof error === 'object' && 'data' in error) {
    const data = (error as { data: unknown }).data;
    if (data && typeof data === 'object' && 'error' in data) return String((data as { error: unknown }).error);
  }
  if (error instanceof TypeError) return 'Could not reach the chat server. Check your connection and try again.';
  return fallback;
}
const statusOf = (error: unknown) => error && typeof error === 'object' && 'status' in error ? Number((error as { status: unknown }).status) : 0;
const newClientId = () => (crypto.randomUUID?.() ?? `${Date.now()}${Math.random()}`).replace(/[^A-Za-z0-9]/g, '').slice(0, 32);

export function useFriendChat(active: boolean) {
  const [session, setSession] = useState<FriendRoomSession | null>(loadSession);
  const [pendingInvite, setPendingInvite] = useState<string | null>(() => takeInviteFromHash());
  const [messages, setMessages] = useState<FriendMessage[]>([]);
  const [participants, setParticipants] = useState<FriendParticipant[]>([]);
  const [expiresAt, setExpiresAt] = useState<string | null>(null);
  const [maxParticipants, setMaxParticipants] = useState(12);
  const [loaded, setLoaded] = useState(false);
  const [pollError, setPollError] = useState('');
  const [ended, setEnded] = useState('');
  const [busy, setBusy] = useState<'create' | 'join' | 'send' | 'leave' | null>(null);
  const cursor = useRef(0);
  const inFlight = useRef(false);
  const pendingClientId = useRef<string | null>(null);

  const reset = useCallback(() => {
    setMessages([]); setParticipants([]); setExpiresAt(null); setLoaded(false); setPollError('');
    cursor.current = 0; pendingClientId.current = null;
  }, []);

  const adopt = useCallback((s: FriendRoomSession) => {
    reset(); setEnded('');
    localStorage.setItem(storageKey, JSON.stringify(s));
    setSession(s);
  }, [reset]);

  const end = useCallback((reason: string) => {
    localStorage.removeItem(storageKey);
    setSession(null); reset(); setEnded(reason);
  }, [reset]);

  const merge = useCallback((incoming: FriendMessage[]) => {
    if (!incoming.length) return;
    setMessages(prev => {
      const byId = new Map(prev.map(m => [m.id, m]));
      incoming.forEach(m => byId.set(m.id, m));
      return [...byId.values()].sort((a, b) => a.id - b.id).slice(-200);
    });
    cursor.current = Math.max(cursor.current, ...incoming.map(m => m.id));
  }, []);

  const poll = useCallback(async () => {
    if (!session || inFlight.current) return;
    inFlight.current = true;
    try {
      const state = await listFriendMessages({ token: session.token, ...(cursor.current ? { after: cursor.current } : {}) });
      merge(state.messages);
      setParticipants(state.participants); setExpiresAt(state.expiresAt); setMaxParticipants(state.maxParticipants);
      setLoaded(true); setPollError('');
    } catch (error) {
      if (statusOf(error) === 401) end('This chat session has ended: you left, or the room expired.');
      else setPollError(errorMessage(error, 'Could not refresh messages.'));
    } finally { inFlight.current = false; }
  }, [session, merge, end]);

  useEffect(() => {
    if (!active || !session) return;
    void poll();
    const id = window.setInterval(() => { if (document.visibilityState === 'visible') void poll(); }, POLL_MS);
    const onVisible = () => { if (document.visibilityState === 'visible') void poll(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { window.clearInterval(id); document.removeEventListener('visibilitychange', onVisible); };
  }, [active, session, poll]);

  const create = async (nickname: string) => {
    setBusy('create');
    try { adopt(await createFriendRoom({ nickname })); }
    finally { setBusy(null); }
  };
  const join = async (roomKey: string, nickname: string) => {
    setBusy('join');
    try { adopt(await joinFriendRoom({ roomKey, nickname })); setPendingInvite(null); }
    finally { setBusy(null); }
  };
  /** Same clientId is reused on retry so a lost response never duplicates the message. */
  const send = async (body: string) => {
    if (!session || busy === 'send') return;
    pendingClientId.current ??= newClientId();
    setBusy('send');
    try {
      const m = await sendFriendMessage({ token: session.token, body, clientId: pendingClientId.current });
      pendingClientId.current = null;
      merge([m]);
    } catch (error) {
      if (statusOf(error) === 401) end('This chat session has ended: you left, or the room expired.');
      throw error;
    } finally { setBusy(null); }
  };
  const draftChanged = () => { pendingClientId.current = null; };
  const leave = async () => {
    if (!session) return;
    setBusy('leave');
    try { await leaveFriendRoom({ token: session.token }); } catch { /* session revoked locally regardless */ }
    finally { setBusy(null); end(''); }
  };

  return { session, pendingInvite, setPendingInvite, messages, participants, expiresAt, maxParticipants, loaded, pollError, ended, busy, create, join, send, leave, draftChanged, retry: poll };
}
