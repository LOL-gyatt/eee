import { useCallback, useEffect, useRef, useState } from 'react';
import { sendMinecraftChat, type MinecraftChatMessage } from '@workspace/api-client-react';

const MAX_QUESTION = 1500;
const MAX_DISPLAY_MESSAGES = 40;

function boundedHistory(messages: MinecraftChatMessage[], question: string): MinecraftChatMessage[] {
  const history = messages.slice(-8);
  // Keep Unicode-heavy conversations under the server's 32 KB body limit too.
  while (history.length && (history.reduce((size, message) => size + message.content.length, 0) > 16_000 ||
    new TextEncoder().encode(JSON.stringify({ question, history })).length > 30_000)) history.splice(0, 2);
  return history;
}

function errorMessage(error: unknown): string {
  if (error && typeof error === 'object' && 'data' in error && error.data &&
      typeof error.data === 'object' && 'error' in error.data && typeof error.data.error === 'string') {
    return error.data.error;
  }
  if (error instanceof TypeError) return 'Could not reach the AI service. Check your connection and retry.';
  return 'The AI service returned an unexpected response. Please retry.';
}

export function useMinecraftChat(active: boolean) {
  const [messages, setMessages] = useState<MinecraftChatMessage[]>([]);
  const [pending, setPending] = useState(false);
  const [lastQuestion, setLastQuestion] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const messagesRef = useRef<MinecraftChatMessage[]>([]);
  const request = useRef<AbortController | null>(null);
  const sequence = useRef(0);
  const lastQuestionRef = useRef<string | null>(null);

  const stop = useCallback((reason = 'Request stopped. You can retry your question.') => {
    if (!request.current) return;
    sequence.current++;
    request.current.abort();
    request.current = null;
    setPending(false);
    setError(reason);
  }, []);

  useEffect(() => {
    if (!active) stop('Request stopped when you left the AI tab. You can retry it here.');
  }, [active, stop]);

  useEffect(() => () => {
    sequence.current++;
    request.current?.abort();
    request.current = null;
  }, []);

  const send = useCallback((rawQuestion: string): boolean => {
    const question = rawQuestion.trim();
    if (!active || request.current || !question) return false;
    if (question.length > MAX_QUESTION) {
      setError(`Keep your question within ${MAX_QUESTION} characters.`);
      return false;
    }
    const controller = new AbortController();
    const id = ++sequence.current;
    request.current = controller;
    lastQuestionRef.current = question;
    setLastQuestion(question);
    setPending(true);
    setError('');
    setNotice('');
    let timedOut = false;
    const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, 75_000);
    void (async () => {
      try {
        const response = await sendMinecraftChat({ question, history: boundedHistory(messagesRef.current, question) }, { signal: controller.signal });
        if (id !== sequence.current) return;
        if (typeof response?.answer !== 'string' || !response.answer.trim() || response.answer.length > 12_000) {
          throw new Error('Invalid AI answer');
        }
        const next = [...messagesRef.current,
          { role: 'user' as const, content: question },
          { role: 'assistant' as const, content: response.answer },
        ].slice(-MAX_DISPLAY_MESSAGES);
        messagesRef.current = next;
        setMessages(next);
        setLastQuestion(null);
        lastQuestionRef.current = null;
      } catch (failure) {
        if (id !== sequence.current) return;
        setError(timedOut ? 'The AI request timed out. Please retry, or ask a shorter question.' : errorMessage(failure));
      } finally {
        clearTimeout(timeout);
        if (id === sequence.current) {
          request.current = null;
          setPending(false);
        }
      }
    })();
    return true;
  }, [active]);

  const clear = useCallback(() => {
    sequence.current++;
    request.current?.abort();
    request.current = null;
    messagesRef.current = [];
    lastQuestionRef.current = null;
    setMessages([]);
    setPending(false);
    setLastQuestion(null);
    setError('');
    setNotice('Chat cleared. Your collection progress is unchanged.');
  }, []);

  const retry = () => { if (lastQuestionRef.current) send(lastQuestionRef.current); };
  return { messages, pending, lastQuestion, error, notice, send, stop, clear, retry, maxQuestion: MAX_QUESTION };
}