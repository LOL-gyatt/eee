import { useState, useEffect, useMemo } from 'react';
import { useGetXboxAchievements, useLookupXboxPlayer, getGetXboxAchievementsQueryKey, type XboxPlayer, type XboxAchievementList } from '@workspace/api-client-react';
import { achievements } from '@/achievements';

type Selection = { xuid: string; gamertag: string; titleId: string; titles: XboxPlayer['titles'] };
const selectionKey = 'blockbound_xbox_selection';
const progressKey = (xuid: string, titleId: string) => `blockbound_xbox_progress_${xuid}_${titleId}`;
function storedSelection(): Selection | null {
  try {
    const value = JSON.parse(localStorage.getItem(selectionKey) || 'null');
    return value && /^[0-9]{1,20}$/.test(value.xuid) && /^[0-9]{1,20}$/.test(value.titleId) &&
      Array.isArray(value.titles) && value.titles.some((t: { titleId: string }) => t.titleId === value.titleId) ? value : null;
  } catch { return null; }
}
function storedProgress(selection: Selection | null): XboxAchievementList | null {
  if (!selection) return null;
  try {
    const value = JSON.parse(localStorage.getItem(progressKey(selection.xuid, selection.titleId)) || 'null');
    return value && Array.isArray(value.achievements) && typeof value.refreshedAt === 'string' ? value : null;
  } catch { return null; }
}
// Question marks distinguish "The End?" / "The End." and the Beginning pair.
const normalize = (name: string) => name.normalize('NFKC').toLocaleLowerCase('en-US').replace(/[\u2018\u2019]/g, "'").replace(/[^a-z0-9?]+/g, '');
// No fuzzy matching: explicit known alternate public Xbox labels only.
const aliases: Record<string, string> = {};

export function matchAchievements(entries: XboxAchievementList['achievements']) {
  const byName = new Map<string, string[]>();
  for (const item of achievements) {
    const key = normalize(item.name);
    byName.set(key, [...(byName.get(key) || []), item.id]);
  }
  const matched = new Set<string>();
  const used = new Set<string>();
  const mappedAchievements: { itemId: string; entry: XboxAchievementList['achievements'][number] }[] = [];
  const unmatched: XboxAchievementList['achievements'] = [];
  for (const entry of entries) {
    const key = normalize(entry.name);
    const candidates = byName.get(key) || byName.get(normalize(aliases[key] || '')) || [];
    if (candidates.length !== 1 || used.has(candidates[0])) { unmatched.push(entry); continue; }
    used.add(candidates[0]);
    mappedAchievements.push({ itemId: candidates[0], entry });
    if (entry.achieved) matched.add(candidates[0]);
  }
  return { unlocked: matched, mapped: used, mappedAchievements, unmatched, mappedCount: used.size };
}

export function useXbox() {
  const [selection, setSelection] = useState<Selection | null>(storedSelection);
  const [profile, setProfile] = useState<XboxPlayer | null>(null);
  const [cached, setCached] = useState<XboxAchievementList | null>(() => storedProgress(storedSelection()));
  const lookup = useLookupXboxPlayer();
  const params = { xuid: selection?.xuid || '', titleId: selection?.titleId || '' };
  const query = useGetXboxAchievements(params, {
    query: {
      queryKey: getGetXboxAchievementsQueryKey(params),
      enabled: !!selection,
      staleTime: 14 * 60_000,
      refetchInterval: () => document.visibilityState === 'visible' ? 15 * 60_000 : false,
      refetchOnWindowFocus: false,
      retry: false,
    },
  });
  useEffect(() => {
    if (selection) localStorage.setItem(selectionKey, JSON.stringify(selection));
    else localStorage.removeItem(selectionKey);
    setCached(storedProgress(selection));
  }, [selection]);
  useEffect(() => {
    if (!selection || !query.data) return;
    setCached(query.data);
    localStorage.setItem(progressKey(selection.xuid, selection.titleId), JSON.stringify(query.data));
  }, [selection, query.data]);
  const data = query.data || cached;
  const match = useMemo(() => data ? matchAchievements(data.achievements) : null, [data]);
  async function find(gamertag: string) {
    setProfile(null);
    const player = await lookup.mutateAsync({ data: { gamertag: gamertag.trim() } });
    setProfile(player);
    return player;
  }
  function select(player: XboxPlayer, titleId: string) {
    if (!player.titles.some(t => t.titleId === titleId)) return;
    setSelection({ xuid: player.xuid, gamertag: player.gamertag, titleId, titles: player.titles });
    setCached(storedProgress({ xuid: player.xuid, gamertag: player.gamertag, titleId, titles: player.titles }));
    setProfile(null);
  }
  function disconnect() { setSelection(null); setCached(null); setProfile(null); lookup.reset(); }
  return { selection, profile, data, match, lookup, find, select, disconnect, query };
}