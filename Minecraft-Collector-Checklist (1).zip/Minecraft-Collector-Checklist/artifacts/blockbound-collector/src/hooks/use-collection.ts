import { useState, useEffect } from 'react';

export function useCollection() {
  const [collected, setCollected] = useState<Set<string>>(() => {
    const saved = localStorage.getItem('blockbound_collected');
    if (saved) {
      try {
        return new Set(JSON.parse(saved));
      } catch (e) {
        return new Set();
      }
    }
    return new Set();
  });

  useEffect(() => {
    localStorage.setItem('blockbound_collected', JSON.stringify(Array.from(collected)));
  }, [collected]);

  const toggleCollected = (id: string) => {
    setCollected(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const reset = () => setCollected(new Set());

  return { collected, toggleCollected, reset };
}
