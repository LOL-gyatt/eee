import { useState, useMemo } from 'react';
import { Search, PawPrint, Shirt, MapPin, Info, Check, Trash2, X, FilterX, Disc, Shapes, FileImage, Wind, Trophy, Bot, Users, Radio } from 'lucide-react';
import { collectibles, type Category, type Rarity, type Collectible } from '@/data';
import { useCollection } from '@/hooks/use-collection';
import { useXbox } from '@/hooks/use-xbox';
import { cn } from '@/lib/utils';
import { MinecraftChat } from '@/components/MinecraftChat';
import { OnlineTracker } from '@/components/OnlineTracker';
import { FriendChat } from '@/components/FriendChat';
import { hasInviteInHash } from '@/hooks/use-friend-chat';
import { AchievementProgress } from '@/components/AchievementProgress';

const categoryIcons: Record<Category, React.ElementType> = {
  'Armor Trim': Shirt,
  'Wolf': PawPrint,
  'Music Disc': Disc,
  'Pottery Sherd': Shapes,
  'Banner Pattern': FileImage,
  'Goat Horn': Wind,
  'Achievement': Trophy
};

type StatusFilter = 'All' | 'Collected' | 'Missing';
type CategoryFilter = 'All' | Category;
type RarityFilter = 'All' | Rarity;
type View = 'all' | 'latest' | 'ai' | 'friends' | 'online';

function unlockDate(value: string | null | undefined): number | null {
  if (!value || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/i.test(value)) return null;
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : null;
}

function ProgressBar({ value, total, label, compact = false }: { value: number, total: number, label: string, compact?: boolean }) {
  const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
  return (
    <div className="space-y-1.5 w-full">
      <div className={cn("flex justify-between font-bold", compact ? "text-xs" : "text-sm")}>
        <span className="text-muted-foreground uppercase tracking-wider">{label}</span>
        <span className="text-foreground">{value} <span className="text-muted-foreground/50 mx-0.5">/</span> {total} {compact ? "" : <span className="text-primary ml-1">({percentage}%)</span>}</span>
      </div>
      <div className={cn("bg-secondary rounded-full overflow-hidden border border-border relative", compact ? "h-2" : "h-3.5")}>
        <div 
          className="h-full bg-primary transition-all duration-700 ease-out shadow-[inset_0_2px_4px_rgba(255,255,255,0.2)]"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}

function FilterGroup({ label, children }: { label: string, children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground ml-1">{label}</span>
      <div className="flex flex-wrap gap-2">
        {children}
      </div>
    </div>
  );
}

function FilterPill({ active, onClick, children, colorClass = "" }: { active: boolean, onClick: () => void, children: React.ReactNode, colorClass?: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-4 py-2 rounded-xl text-sm font-bold transition-all border-2",
        active 
          ? "bg-primary border-primary text-primary-foreground shadow-[0_4px_15px_rgba(69,184,129,0.3)]" 
          : "bg-input border-border text-foreground hover:border-primary/50 hover:bg-card"
      )}
    >
      <span className={cn(!active && colorClass, "flex items-center gap-1.5")}>{children}</span>
    </button>
  );
}

function ConfirmDialog({ isOpen, onClose, onConfirm, title, description }: { isOpen: boolean, onClose: () => void, onConfirm: () => void, title: string, description: string }) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card border-2 border-border p-6 rounded-3xl shadow-2xl max-w-sm w-full animate-in zoom-in-95 duration-200">
        <div className="w-14 h-14 rounded-2xl bg-destructive/10 text-destructive flex items-center justify-center mb-5 border border-destructive/20 transform -rotate-3">
          <Trash2 size={28} />
        </div>
        <h3 className="text-2xl font-black mb-2">{title}</h3>
        <p className="text-muted-foreground mb-8 font-medium text-sm leading-relaxed">{description}</p>
        <div className="flex justify-end gap-3">
          <button 
            onClick={onClose} 
            className="px-5 py-2.5 rounded-xl font-bold bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors border-2 border-transparent"
          >
            Cancel
          </button>
          <button 
            onClick={() => { onConfirm(); onClose(); }} 
            className="px-5 py-2.5 rounded-xl font-bold bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors border-2 border-destructive shadow-[0_0_15px_rgba(220,38,38,0.3)]"
          >
            Yes, Reset All
          </button>
        </div>
      </div>
    </div>
  );
}

function ItemThumbnail({ item, isCollected }: { item: Collectible, isCollected: boolean }) {
  const [error, setError] = useState(false);
  const extension = item.category === 'Wolf' ? 'jpg' : 'png';
  const src = `${import.meta.env.BASE_URL}${item.image ?? `item-images/${item.id}.${extension}`}`;
  const hornLabel = item.category === 'Goat Horn'
    ? item.name.replace(' Goat Horn', '').slice(0, 4).toUpperCase()
    : null;
  
  if (error && item.category === 'Achievement') {
    return <div role="img" aria-label={`Achievement icon unavailable: ${item.name}`} className="w-14 h-14 shrink-0 rounded-xl border border-destructive text-destructive text-xs font-bold flex items-center justify-center">Image unavailable</div>;
  }
  if (error) {
    const Icon = categoryIcons[item.category] || Info;
    return (
      <div className={cn(
        "w-14 h-14 shrink-0 rounded-2xl flex items-center justify-center border transition-all duration-300 shadow-inner",
        isCollected 
          ? "bg-primary text-primary-foreground border-white/20 scale-105" 
          : "bg-secondary text-muted-foreground border-white/5 group-hover:bg-secondary/70 group-hover:text-foreground"
      )}>
        <Icon size={28} />
      </div>
    );
  }

  return (
    <div className={cn(
      item.category === 'Achievement' ? "w-24 h-[55px] shrink-0 rounded-xl overflow-hidden border transition-all duration-300 relative" : "w-14 h-14 shrink-0 rounded-2xl overflow-hidden border transition-all duration-300 relative",
      isCollected ? "border-primary/50 scale-105 shadow-[0_0_10px_rgba(69,184,129,0.3)]" : "border-white/10 shadow-inner group-hover:border-primary/30"
    )}>
      {!isCollected && <div className="absolute inset-0 bg-black/40 z-10 transition-colors group-hover:bg-black/20 mix-blend-overlay" />}
      <img 
        src={src} 
        alt={item.name} 
        onError={() => setError(true)}
        className={cn(
          "w-full h-full",
           item.category === 'Wolf' ? "object-cover" : item.category === 'Achievement' ? "object-contain [image-rendering:pixelated]" : "object-contain p-2 [image-rendering:pixelated]"
        )}
      />
      {hornLabel && (
        <span className="absolute inset-x-1 bottom-1 z-20 rounded bg-background/90 px-1 py-0.5 text-center text-[8px] font-black tracking-wider text-primary">
          {hornLabel}
        </span>
      )}
    </div>
  );
}

function ItemCard({ item, isCollected, onClick, readOnly = false, unmapped = false }: { item: Collectible, isCollected: boolean, onClick: () => void, readOnly?: boolean, unmapped?: boolean }) {
  const rarityColors = {
    Common: "text-zinc-300 border-zinc-700/50 bg-zinc-800/20",
    Rare: "text-emerald-400 border-emerald-900/60 bg-emerald-950/30",
    Epic: "text-fuchsia-400 border-fuchsia-900/60 bg-fuchsia-950/30",
  };

  return (
    <div
      role={readOnly ? undefined : "button"}
      tabIndex={readOnly ? undefined : 0}
      aria-pressed={isCollected}
      aria-label={readOnly ? `${item.name}: ${unmapped ? 'not mapped to Xbox data' : isCollected ? 'unlocked' : 'not unlocked'} (read-only)` : `${isCollected ? 'Mark incomplete' : 'Mark complete'}: ${item.name}`}
      data-testid={`card-collectible-${item.id}`}
      onClick={readOnly ? undefined : onClick}
      onKeyDown={readOnly ? undefined : e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onClick(); } }}
      className={cn(
        "relative flex flex-col p-5 rounded-3xl border-2 transition-all duration-300 group text-left h-full overflow-hidden",
        !readOnly && "cursor-pointer",
        isCollected 
          ? "border-primary bg-primary/5 shadow-[0_0_20px_rgba(69,184,129,0.08)]" 
          : "border-border bg-card hover:border-primary/40 "
      )}
    >
      <div className={cn(
        "absolute -right-4 -top-4 w-24 h-24 rounded-full blur-2xl opacity-0 transition-opacity duration-500",
        isCollected && "bg-primary/20 opacity-100"
      )} />

      <div className="flex justify-between items-start mb-5 relative z-10">
        <div className="flex items-start gap-4">
          <ItemThumbnail item={item} isCollected={isCollected} />
          <div className="pt-0.5">
            <h3 className="font-extrabold text-lg leading-tight mb-2 text-foreground group-hover:text-primary transition-colors">{item.name}</h3>
             <div className="flex flex-wrap gap-1.5">
             {item.category === 'Achievement' && (
               <span className="text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border inline-block text-amber-300 border-amber-700/50 bg-amber-900/20">{item.gamerscore} Gamerscore</span>
             )}
              {unmapped && <span className="text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border text-muted-foreground border-border">Not mapped · status unknown</span>}
             <span title={item.category === 'Achievement' ? 'Estimated difficulty, not official unlock rarity' : undefined} className={cn(
              "text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border inline-block", 
               rarityColors[item.rarity!]
            )}>
              {item.rarity}{item.category === 'Achievement' ? ' · Estimated' : ''}
             </span>
             </div>
          </div>
        </div>
        <div className={cn(
          "w-8 h-8 shrink-0 rounded-xl border-2 flex items-center justify-center transition-all duration-300 shadow-sm",
          isCollected 
            ? "bg-primary border-primary text-primary-foreground scale-110 shadow-[0_0_15px_rgba(69,184,129,0.4)]" 
            : "border-muted-foreground/30 text-transparent group-hover:border-primary/50 bg-input"
        )}>
          <Check size={18} className="stroke-[3.5]" />
        </div>
      </div>

      <div className="space-y-3 mt-auto pt-2 relative z-10">
         {item.category === 'Achievement' ? <>
           <div className="text-sm text-foreground/90 font-medium bg-background/50 p-3 rounded-xl border border-border"><span className="text-primary font-black text-xs uppercase tracking-wider">Description</span><p className="mt-1 leading-snug">{item.description}</p></div>
           <div className="text-sm text-muted-foreground p-1 px-2"><span className="text-blue-400 font-black text-xs uppercase tracking-wider">Actual requirement</span><p className="mt-1 leading-snug">{item.requirement}</p></div>
         </> : <>
           <div className="flex items-start gap-3 text-sm text-foreground/90 font-medium bg-background/50 p-3 rounded-xl border border-border"><MapPin size={18} className="shrink-0 mt-0.5 text-accent" /><span className="leading-snug">{item.location}</span></div>
           <div className="flex items-start gap-3 text-sm text-muted-foreground p-1 px-2"><Info size={18} className="shrink-0 text-blue-400/80" /><span className="leading-snug text-sm">{item.tip}</span></div>
         </>}
      </div>
    </div>
  );
}

export default function Home() {
  const { collected, toggleCollected, reset } = useCollection();
  const xbox = useXbox();
  const [gamertagInput, setGamertagInput] = useState('');
  const [lookupError, setLookupError] = useState('');
  const [selectedTitle, setSelectedTitle] = useState('');
  const [view, setView] = useState<View>(() => hasInviteInHash() ? 'friends' : 'all');
  const synced = xbox.selection !== null;
  const isCollected = (item: Collectible) => item.category === 'Achievement' && synced
    ? !!xbox.match?.unlocked.has(item.id)
    : collected.has(item.id);
  
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<StatusFilter>('All');
  const [category, setCategory] = useState<CategoryFilter>('All');
  const [rarity, setRarity] = useState<RarityFilter>('All');
  
  const [isResetOpen, setIsResetOpen] = useState(false);

  const filtered = useMemo(() => {
    return collectibles.filter(item => {
      if (search && ![item.name, item.location, item.description, item.requirement].some(text => text?.toLowerCase().includes(search.toLowerCase()))) return false;
      if (category !== 'All' && item.category !== category) return false;
      if (rarity !== 'All' && item.rarity !== rarity) return false;
      
       const done = isCollected(item);
       if (status === 'Collected' && !done) return false;
       if (status === 'Missing' && (done || (synced && item.category === 'Achievement' && !xbox.match?.mapped.has(item.id)))) return false;
      
      return true;
    });
   }, [search, status, category, rarity, collected, xbox.match, synced]);

  // Latest is based solely on matched, unlocked Xbox achievements, never on
  // the manual checklist or the independent All collectibles filters.
  const latest = useMemo(() => {
    const items = new Map(collectibles.filter(item => item.category === 'Achievement').map(item => [item.id, item]));
    return (xbox.match?.mappedAchievements || [])
      .filter(({ entry }) => entry.achieved)
      .map(({ itemId, entry }) => ({ item: items.get(itemId), entry, time: unlockDate(entry.unlockedAt) }))
      .filter((row): row is typeof row & { item: Collectible } => !!row.item)
      .sort((a, b) => (b.time ?? -Infinity) - (a.time ?? -Infinity))
      .slice(0, 12);
  }, [xbox.match]);

  const stats = useMemo(() => {
    const total = collectibles.length;
    let currentTotal = 0;
    
    const catStats = {
      'Armor Trim': { total: 0, current: 0 },
      'Wolf': { total: 0, current: 0 },
      'Music Disc': { total: 0, current: 0 },
      'Pottery Sherd': { total: 0, current: 0 },
      'Banner Pattern': { total: 0, current: 0 },
      'Goat Horn': { total: 0, current: 0 },
       'Achievement': { total: 0, current: 0 },
    };

    collectibles.forEach(item => {
      catStats[item.category].total++;
       if (isCollected(item)) {
        currentTotal++;
        catStats[item.category].current++;
      }
    });

    return {
      total, currentTotal,
      categories: catStats
    };
   }, [collected, xbox.match, synced]);

  const clearFilters = () => {
    setSearch('');
    setStatus('All');
    setCategory('All');
    setRarity('All');
  };

  const activeFilterCount = (search ? 1 : 0) + (status !== 'All' ? 1 : 0) + (category !== 'All' ? 1 : 0) + (rarity !== 'All' ? 1 : 0);

  return (
    <div className="mc-app min-h-[100dvh] bg-background text-foreground selection:bg-primary/30 pb-24 font-sans">
      <header className="border-b-4 border-border bg-card/80 sticky top-0 z-40 backdrop-blur-xl">
        <div className="max-w-6xl mx-auto px-4 py-4 md:py-6 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center border-b-4 border-emerald-700 text-primary-foreground shadow-lg transform -rotate-6 transition-transform hover:rotate-0">
              <img src={`${import.meta.env.BASE_URL}compass-icon.png`} alt="" width={40} height={40} className="w-10 h-10 object-contain [image-rendering:pixelated]" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight text-foreground uppercase">Blockbound</h1>
              <p className="text-primary font-bold text-sm tracking-widest uppercase opacity-90 -mt-0.5">Collector's Guide</p>
            </div>
          </div>
          
          <div className="flex-1 max-w-md w-full self-end md:self-auto space-y-3 hidden md:block">
             <AchievementProgress value={stats.categories.Achievement.current} total={stats.categories.Achievement.total} />
          </div>
          
          <button 
            onClick={() => setIsResetOpen(true)}
            className="hidden md:flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary text-secondary-foreground hover:bg-destructive hover:text-destructive-foreground transition-all font-bold text-sm border-2 border-transparent hover:border-destructive/30"
          >
            <Trash2 size={18} />
            <span>Reset</span>
          </button>
        </div>
      </header>
      
      <main className="max-w-6xl mx-auto px-4 py-8">
         <section className="mb-8 bg-card rounded-3xl border-2 border-border p-5 md:p-7 space-y-4" aria-label="Xbox achievement lookup">
           <div className="flex items-center gap-3"><div className="mc-icon-tile"><Trophy size={22} /></div><h2 className="text-xl font-black">Xbox achievement lookup</h2></div>
           <p className="text-sm text-muted-foreground">Look up a public gamertag using OpenXBL. This is not Xbox sign-in or proof of account ownership. Your manual checklist is kept separately and returns when you disconnect. Only achievements change to read-only Xbox progress; all other collectibles stay manual.</p>
           <form className="flex flex-wrap gap-2" onSubmit={async e => {
             e.preventDefault();
             setLookupError('');
             try {
               const player = await xbox.find(gamertagInput);
               setSelectedTitle(player.titles[0]?.titleId || '');
             } catch (error) {
               setLookupError(error instanceof Error && 'data' in error && typeof error.data === 'object' && error.data !== null && 'error' in error.data
                  ? String(error.data.error)
                  : error instanceof Error && error.name === 'ResponseParseError'
                    ? 'The lookup received an invalid server response. Reload the preview and try again.'
                    : error instanceof TypeError
                      ? 'Could not reach the lookup service. Check your connection, reload the preview, and try again.'
                      : 'Could not complete the lookup. Reload the preview and try again.');
             }
           }}>
             <input aria-label="Public Xbox gamertag" value={gamertagInput} onChange={e => setGamertagInput(e.target.value)}
               maxLength={30} placeholder="Enter a gamertag" className="flex-1 min-w-[190px] bg-input border-2 border-border rounded-xl px-4 py-2 font-semibold focus:border-primary outline-none" />
             <button disabled={xbox.lookup.isPending} className="bg-primary text-primary-foreground px-5 py-2 rounded-xl font-bold disabled:opacity-50">
               {xbox.lookup.isPending ? 'Looking up…' : synced ? 'Find another player' : 'Find player'}
             </button>
           </form>
           {lookupError && <p role="alert" className="text-destructive text-sm">{lookupError}</p>}
           {xbox.profile && <div className="bg-secondary/40 rounded-xl p-4 space-y-3">
             <p className="font-bold">Public profile: {xbox.profile.gamertag}</p>
             {xbox.profile.titles.length ? <>
               <label className="block text-sm text-muted-foreground" htmlFor="bedrock-title">Choose Minecraft Bedrock platform title</label>
               <select id="bedrock-title" value={selectedTitle} onChange={e => setSelectedTitle(e.target.value)} className="bg-input border border-border rounded-xl px-3 py-2 w-full text-foreground">
                 {xbox.profile.titles.map(title => <option value={title.titleId} key={title.titleId}>{title.name} · {title.titleId}</option>)}
               </select>
               <button type="button" onClick={() => xbox.select(xbox.profile!, selectedTitle)} className="bg-primary text-primary-foreground rounded-xl px-4 py-2 font-bold">View achievements</button>
             </> : <p className="text-sm text-muted-foreground">No public Minecraft Bedrock title with achievements was found in this player's title history. Legacy editions, Java, Dungeons and Legends are excluded.</p>}
           </div>}
           {xbox.selection && <div className="flex flex-wrap items-center justify-between gap-3 bg-primary/5 border border-primary/30 rounded-xl p-4">
             <div>
               <p className="font-bold">{xbox.selection.gamertag} · {xbox.selection.titles.find(t => t.titleId === xbox.selection?.titleId)?.name}</p>
               <p className="text-sm text-muted-foreground">
                 {xbox.query.isFetching ? 'Checking public Xbox progress… ' : ''}
                 {xbox.data ? `Last successful refresh: ${new Date(xbox.data.refreshedAt).toLocaleString()}.` : 'No successful sync yet.'}
                 {' '}Auto-checks roughly every 15 minutes while this page is open and visible.
               </p>
               {xbox.query.isError && <p role="alert" className="text-sm text-destructive">Refresh failed: the profile may be private or Xbox lookup unavailable. {xbox.data ? 'Showing last successful result.' : 'No achievements can be confirmed yet.'}</p>}
             </div>
             <div className="flex gap-2">
               <button type="button" disabled={xbox.query.isFetching} onClick={() => xbox.query.refetch()} className="bg-secondary border border-border rounded-xl px-4 py-2 font-bold disabled:opacity-50">Refresh</button>
               <button type="button" onClick={xbox.disconnect} className="bg-secondary border border-border rounded-xl px-4 py-2 font-bold">Disconnect</button>
             </div>
             {xbox.selection.titles.length > 1 && <div className="w-full">
               <label htmlFor="switch-bedrock" className="text-sm text-muted-foreground mr-2">Platform title</label>
               <select id="switch-bedrock" value={xbox.selection.titleId} onChange={e => xbox.select({ xuid: xbox.selection!.xuid, gamertag: xbox.selection!.gamertag, titles: xbox.selection!.titles }, e.target.value)}
                 className="bg-input border border-border rounded-xl px-3 py-2 text-foreground">
                 {xbox.selection.titles.map(t => <option value={t.titleId} key={t.titleId}>{t.name} · {t.titleId}</option>)}
               </select>
             </div>}
           </div>}
         </section>
        
        <div className="md:hidden flex flex-col gap-5 mb-8 bg-card p-5 rounded-3xl border-2 border-border shadow-sm relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-32 h-32 bg-primary/5 rounded-full blur-2xl" />
          <AchievementProgress value={stats.categories.Achievement.current} total={stats.categories.Achievement.total} />
          
          <div className="grid grid-cols-2 gap-x-4 gap-y-4 mt-2">
            <ProgressBar value={stats.categories['Armor Trim'].current} total={stats.categories['Armor Trim'].total} label="Armor Trims" compact />
            <ProgressBar value={stats.categories['Wolf'].current} total={stats.categories['Wolf'].total} label="Wolves" compact />
            <ProgressBar value={stats.categories['Music Disc'].current} total={stats.categories['Music Disc'].total} label="Discs" compact />
            <ProgressBar value={stats.categories['Pottery Sherd'].current} total={stats.categories['Pottery Sherd'].total} label="Sherds" compact />
            <ProgressBar value={stats.categories['Banner Pattern'].current} total={stats.categories['Banner Pattern'].total} label="Banners" compact />
            <ProgressBar value={stats.categories['Goat Horn'].current} total={stats.categories['Goat Horn'].total} label="Horns" compact />
             <ProgressBar value={stats.categories['Achievement'].current} total={stats.categories['Achievement'].total} label="Achievements" compact />
          </div>

          <button 
            onClick={() => setIsResetOpen(true)}
            className="mt-3 w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-secondary/50 text-secondary-foreground hover:bg-destructive hover:text-destructive-foreground transition-colors font-bold text-sm border-2 border-border"
          >
            <Trash2 size={18} />
            <span>Reset Journey</span>
          </button>
        </div>

        <div className="hidden md:grid grid-cols-3 gap-6 mb-12 bg-card p-8 rounded-3xl border-2 border-border shadow-sm relative overflow-hidden">
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-32 bg-primary/5 blur-3xl rounded-full" />
          <div className="relative z-10"><ProgressBar value={stats.categories['Armor Trim'].current} total={stats.categories['Armor Trim'].total} label="Armor Trims" /></div>
          <div className="relative z-10"><ProgressBar value={stats.categories['Wolf'].current} total={stats.categories['Wolf'].total} label="Wolves" /></div>
          <div className="relative z-10"><ProgressBar value={stats.categories['Music Disc'].current} total={stats.categories['Music Disc'].total} label="Music Discs" /></div>
          <div className="relative z-10"><ProgressBar value={stats.categories['Pottery Sherd'].current} total={stats.categories['Pottery Sherd'].total} label="Pottery Sherds" /></div>
          <div className="relative z-10"><ProgressBar value={stats.categories['Banner Pattern'].current} total={stats.categories['Banner Pattern'].total} label="Banner Patterns" /></div>
          <div className="relative z-10"><ProgressBar value={stats.categories['Goat Horn'].current} total={stats.categories['Goat Horn'].total} label="Goat Horns" /></div>
           <div className="relative z-10"><ProgressBar value={stats.categories['Achievement'].current} total={stats.categories['Achievement'].total} label="Achievements" /></div>
        </div>

         <div role="tablist" aria-label="Collection views" className="mc-hotbar flex flex-wrap gap-2 mb-8">
           <button type="button" id="tab-all" role="tab" aria-controls="panel-all" aria-selected={view === 'all'} onClick={() => setView('all')}
             className={cn("px-5 py-3 rounded-xl font-bold border-2 transition-colors", view === 'all' ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50")}>
             All collectibles
           </button>
           <button type="button" id="tab-latest" role="tab" aria-controls="panel-latest" aria-selected={view === 'latest'} onClick={() => setView('latest')}
             className={cn("px-5 py-3 rounded-xl font-bold border-2 transition-colors flex items-center gap-2", view === 'latest' ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50")}>
             <Trophy size={18} /> Latest achievements
           </button>
            <button type="button" id="tab-ai" role="tab" aria-controls="panel-ai" aria-selected={view === 'ai'} onClick={() => setView('ai')} data-testid="tab-minecraft-ai"
              className={cn("px-5 py-3 rounded-xl font-bold border-2 transition-colors flex items-center gap-2", view === 'ai' ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50")}>
              <Bot size={18} /> Minecraft AI
            </button>
            <button type="button" id="tab-friends" role="tab" aria-controls="panel-friends" aria-selected={view === 'friends'} onClick={() => setView('friends')} data-testid="tab-friend-chat"
              className={cn("px-5 py-3 rounded-xl font-bold border-2 transition-colors flex items-center gap-2", view === 'friends' ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50")}>
              <Users size={18} /> Friend Chat
            </button>
            <button type="button" id="tab-online" role="tab" aria-controls="panel-online" aria-selected={view === 'online'} onClick={() => setView('online')}
              className={cn("px-5 py-3 rounded-xl font-bold border-2 transition-colors flex items-center gap-2", view === 'online' ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50")}>
              <Radio size={18} /> Online Tracker
            </button>
          </div>

           <OnlineTracker active={view === 'online'} />
           <MinecraftChat active={view === 'ai'} />
           <FriendChat active={view === 'friends'} />
         {view === 'all' ? <div id="panel-all" role="tabpanel" aria-labelledby="tab-all">
         <div className="space-y-8 mb-12">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="w-full md:max-w-lg relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" size={22} />
              <input 
                type="text" 
                placeholder="Search name, location or achievement..." 
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full bg-input border-2 border-border focus:border-primary rounded-2xl py-4 pl-14 pr-12 text-foreground placeholder:text-muted-foreground transition-colors outline-none font-semibold shadow-inner text-lg"
              />
              {search && (
                <button onClick={() => setSearch('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground bg-secondary/50 p-1.5 rounded-full transition-colors">
                  <X size={18} className="stroke-[3]" />
                </button>
              )}
            </div>
            
            {activeFilterCount > 0 && (
              <button 
                onClick={clearFilters}
                className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-secondary/80 text-secondary-foreground hover:bg-secondary transition-all font-bold whitespace-nowrap border-2 border-border hover:border-muted-foreground/30 shadow-sm"
              >
                <FilterX size={18} />
                Clear Filters
              </button>
            )}
          </div>
          
          <div className="flex flex-wrap gap-x-10 gap-y-8 bg-card/40 p-6 rounded-3xl border border-border/50">
            <FilterGroup label="Category">
              <FilterPill active={category === 'All'} onClick={() => setCategory('All')}>All Types</FilterPill>
              <FilterPill active={category === 'Armor Trim'} onClick={() => setCategory('Armor Trim')}>
                <Shirt size={16} /> Armor Trims
              </FilterPill>
              <FilterPill active={category === 'Wolf'} onClick={() => setCategory('Wolf')}>
                <PawPrint size={16} /> Wolves
              </FilterPill>
              <FilterPill active={category === 'Music Disc'} onClick={() => setCategory('Music Disc')}>
                <Disc size={16} /> Music Discs
              </FilterPill>
              <FilterPill active={category === 'Pottery Sherd'} onClick={() => setCategory('Pottery Sherd')}>
                <Shapes size={16} /> Pottery Sherds
              </FilterPill>
              <FilterPill active={category === 'Banner Pattern'} onClick={() => setCategory('Banner Pattern')}>
                <FileImage size={16} /> Banner Patterns
              </FilterPill>
              <FilterPill active={category === 'Goat Horn'} onClick={() => setCategory('Goat Horn')}>
                <Wind size={16} /> Goat Horns
              </FilterPill>
               <FilterPill active={category === 'Achievement'} onClick={() => setCategory('Achievement')}>
                 <Trophy size={16} /> Achievements
               </FilterPill>
            </FilterGroup>
            
            <FilterGroup label="Status">
              <FilterPill active={status === 'All'} onClick={() => setStatus('All')}>Any</FilterPill>
              <FilterPill active={status === 'Collected'} onClick={() => setStatus('Collected')}>Collected</FilterPill>
              <FilterPill active={status === 'Missing'} onClick={() => setStatus('Missing')}>Missing</FilterPill>
            </FilterGroup>

            <FilterGroup label="Rarity">
              <FilterPill active={rarity === 'All'} onClick={() => setRarity('All')}>All</FilterPill>
              <FilterPill active={rarity === 'Common'} onClick={() => setRarity('Common')} colorClass="text-zinc-300">Common</FilterPill>
              <FilterPill active={rarity === 'Rare'} onClick={() => setRarity('Rare')} colorClass="text-emerald-400">Rare</FilterPill>
              <FilterPill active={rarity === 'Epic'} onClick={() => setRarity('Epic')} colorClass="text-fuchsia-400">Epic</FilterPill>
            </FilterGroup>
          </div>
        </div>

         {(category === 'Achievement' || category === 'All') && <div className="mb-8 rounded-2xl border border-primary/30 bg-primary/5 px-5 py-4 text-sm text-muted-foreground leading-relaxed">
            <strong className="text-foreground">Bedrock achievements · {stats.categories.Achievement.total} curated</strong> — {synced ? 'Read-only public Xbox achievement progress (not authenticated account ownership). Unmapped curated entries have unknown status; mapping coverage is shown below.' : 'Manual checklist. You can look up public Xbox progress above.'} In-game achievements generally require Survival mode with cheats disabled; Creative mode and enabling cheats disable earning achievements in that world. Platform availability and trophy counts may differ.
           <p className="mt-2">Achievement rarity is an estimated difficulty rating, not official unlock statistics: Common = routine survival, Rare = exploration or special setup, Epic = demanding challenges, scarce loot, bosses or long grinds. Gamerscore is shown separately.</p>
            {synced && xbox.data && <p className="mt-2">Matched {xbox.match?.mappedCount || 0} of {xbox.data.achievements.length} provider achievements to the curated list. {stats.categories.Achievement.total - (xbox.match?.mappedCount || 0)} curated entries have unknown status (excluded from Missing). {xbox.match?.unmatched.length || 0} provider entries unmatched, including {xbox.match?.unmatched.filter(entry => entry.achieved).length || 0} unlocked. Unmatched entries are not counted as curated completion.</p>}
            {synced && xbox.match && xbox.match.unmatched.filter(entry => entry.achieved).length > 0 && <details className="mt-2"><summary className="cursor-pointer">Provider-only unlocked achievements</summary><ul className="list-disc ml-5 mt-2">{xbox.match.unmatched.filter(entry => entry.achieved).map(entry => <li key={entry.id}>{entry.name}</li>)}</ul></details>}
         </div>}
        
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map(item => (
              <ItemCard 
                key={item.id} 
                item={item} 
                isCollected={isCollected(item)}
                readOnly={synced && item.category === 'Achievement'}
                unmapped={synced && item.category === 'Achievement' && !!xbox.match && !xbox.match.mapped.has(item.id)}
                onClick={() => toggleCollected(item.id)}
              />
            ))}
          </div>
        ) : (
          <div className="py-24 text-center flex flex-col items-center bg-card/30 rounded-3xl border-2 border-dashed border-border">
            <div className="w-24 h-24 bg-card rounded-3xl flex items-center justify-center border-4 border-border mb-6 transform rotate-3 shadow-lg">
              <Search size={40} className="text-muted-foreground" />
            </div>
            <h3 className="text-3xl font-extrabold mb-3">No items found</h3>
            <p className="text-muted-foreground max-w-md mx-auto mb-8 font-medium text-lg leading-relaxed">
              We couldn't find any collectibles matching your filters. The wild is vast, but maybe try adjusting your search.
            </p>
            <button 
              onClick={clearFilters}
              className="px-8 py-4 bg-primary text-primary-foreground font-black text-lg rounded-2xl shadow-[0_8px_30px_rgba(69,184,129,0.4)] hover:bg-primary/90 hover:-translate-y-1 transition-all"
            >
              Clear All Filters
            </button>
          </div>
         )}
          </div> : view === 'latest' ? <section id="panel-latest" role="tabpanel" aria-labelledby="tab-latest" className="space-y-5">
           <div>
             <h2 className="text-2xl font-black">Latest achievements</h2>
             <p className="text-sm text-muted-foreground mt-1">Up to 12 unlocked, matched Minecraft Bedrock achievements from the selected public Xbox title, newest unlock first. Dates come from Xbox; achievements without a reported unlock time appear last. All collectibles filters do not apply here.</p>
           </div>
           {!synced ? (
             <div className="bg-card rounded-2xl border border-border p-8 text-muted-foreground">Look up a public Xbox gamertag and choose a Minecraft Bedrock title above to see its latest unlocked achievements. Manual checklist completion does not include unlock dates.</div>
           ) : !xbox.data ? (
             <div className="bg-card rounded-2xl border border-border p-8 text-muted-foreground" role="status">
               {xbox.query.isError ? 'Xbox achievements could not be loaded. Try Refresh above or check that the public profile is available.' : 'Loading public Xbox achievements…'}
             </div>
           ) : <>
             {xbox.query.isError && <p role="alert" className="text-sm text-destructive">Refresh failed. Showing the last successful Xbox result; recent unlocks may be missing.</p>}
             {latest.length ? (
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {latest.map(({ item, entry, time }) => (
                   <div key={item.id} className="flex flex-col gap-2">
                     <div className="rounded-xl border border-primary/30 bg-primary/5 px-4 py-2 text-sm font-bold text-primary">
                       {time !== null ? <>Unlocked <time dateTime={entry.unlockedAt!}>{new Date(time).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}</time></> : 'Unlock date unknown · Xbox did not report a time'}
                     </div>
                     <ItemCard item={item} isCollected={true} readOnly onClick={() => {}} />
                   </div>
                 ))}
               </div>
             ) : (
               <div className="bg-card rounded-2xl border border-border p-8 text-muted-foreground">No unlocked Xbox achievements matched the curated Minecraft Bedrock list for this title. Unmatched provider achievements are not shown here; see the coverage details in All collectibles.</div>
             )}
           </>}
          </section> : null}
      </main>

      <ConfirmDialog 
        isOpen={isResetOpen}
        onClose={() => setIsResetOpen(false)}
        onConfirm={reset}
        title="Reset Progress?"
         description="Clear your manual checklist? Xbox lookup and its cached result are unaffected. This cannot be undone."
      />
    </div>
  );
}
