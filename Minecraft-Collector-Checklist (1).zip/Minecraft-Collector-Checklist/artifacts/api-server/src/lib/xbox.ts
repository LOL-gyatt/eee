// OpenXBL v2 search, title history, and specific-title achievement contracts:
// https://api.xbl.io/docs/json
type RecordValue = Record<string, unknown>;
const object = (value: unknown): RecordValue =>
  value !== null && typeof value === "object" && !Array.isArray(value) ? value as RecordValue : {};
const array = (value: unknown): unknown[] => Array.isArray(value) ? value : [];
const text = (value: unknown): string => typeof value === "string" ? value : "";
const identifier = (value: unknown): string => String(value ?? "");
const validId = (value: unknown): boolean => /^[0-9]{1,20}$/.test(identifier(value));
// The Xbox achievement payload carries the unlock time in progression.timeUnlocked.
// Only expose an actual, unambiguous provider timestamp for unlocked entries.
const unlockTime = (value: unknown): string | null => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/i.test(value)) return null;
  return Number.isFinite(Date.parse(value)) ? value : null;
};

export class XboxError extends Error {
  status: number;
  constructor(status: number, message: string) { super(message); this.status = status; }
}

const cache = new Map<string, { expires: number; value: unknown }>();
const pending = new Map<string, Promise<unknown>>();
const requestTimes: number[] = [];
let throttleUntil = 0;

async function provider(path: string): Promise<unknown> {
  const key = process.env.OPENXBL_API_KEY;
  if (!key) throw new XboxError(503, "Xbox lookup is not configured right now.");
  const now = Date.now();
  while (requestTimes.length && requestTimes[0] < now - 3_600_000) requestTimes.shift();
  // Reserve 30 requests/hour below the advertised 150/hour limit for other uses.
  if (requestTimes.length >= 120 || now < throttleUntil)
    throw new XboxError(429, "Xbox lookup is temporarily rate limited. Please try again later.");
  requestTimes.push(now);
  let response: Response;
  try {
    response = await fetch(`https://api.xbl.io${path}`, {
      headers: { "X-Authorization": key, "Accept-Language": "en-US" },
      signal: AbortSignal.timeout(10_000),
    });
  } catch {
    throw new XboxError(504, "Xbox lookup timed out. Please try again later.");
  }
  if (response.status === 429) {
    const retry = Number(response.headers.get("retry-after"));
    throttleUntil = Date.now() + (Number.isFinite(retry) && retry > 0 ? Math.min(retry, 3600) : 60) * 1000;
    throw new XboxError(429, "Xbox lookup is rate limited. Please try again later.");
  }
  if (response.status === 401 || response.status === 403)
    throw new XboxError(502, "Xbox provider access is unavailable. Contact the site owner.");
  if (response.status === 404) throw new XboxError(404, "This public Xbox data was not found or is private.");
  if (!response.ok) throw new XboxError(502, "Xbox provider is unavailable. Please try again later.");
  try {
    const payload: unknown = await response.json();
    const body = object(payload);
    // OpenXBL can return failures inside an HTTP 200 ApiResponse.
    if (body.code === 429) {
      throttleUntil = Date.now() + 60_000;
      throw new XboxError(429, "Xbox lookup is rate limited. Please try again later.");
    }
    if (body.code === 404) throw new XboxError(404, "This public Xbox data was not found or is private.");
    if (body.code === 401 || body.code === 403)
      throw new XboxError(502, "Xbox provider access is unavailable. Contact the site owner.");
    if (typeof body.code === "number" && body.code !== 200)
      throw new XboxError(502, "Xbox provider returned an unexpected response.");
    return body.content ?? payload; // preserve bare arrays as well as ApiResponse envelopes
  } catch (error) {
    if (error instanceof XboxError) throw error;
    throw new XboxError(502, "Xbox provider returned an invalid response.");
  }
}

function cached<T>(key: string, ttl: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return Promise.resolve(hit.value as T);
  const running = pending.get(key);
  if (running) return running as Promise<T>;
  const work = load().then(value => {
    if (cache.size >= 300) cache.delete(cache.keys().next().value!);
    cache.set(key, { expires: Date.now() + ttl, value });
    return value;
  }).finally(() => pending.delete(key));
  pending.set(key, work);
  return work;
}

export const validXuid = validId;
export const validGamertag = (tag: unknown): tag is string =>
  typeof tag === "string" && /^(?=.{1,30}$)[\p{L}\p{N}][\p{L}\p{N} _.-]*$/u.test(tag) && tag.trim() === tag;

export function isBedrockTitle(name: string): boolean {
  // Explicit Bedrock product names only. Excludes Java, Dungeons, Legends,
  // "Minecraft: Xbox One Edition", Xbox 360/legacy console editions and Story Mode.
  return /^Minecraft(?: for Windows| for Nintendo Switch| for PlayStation®?| for Xbox| for iOS| for Android| for Apple TV| for Kindle Fire| for Gear VR|: Windows 10 Edition|: Pocket Edition|: Bedrock Edition| \(.*Bedrock.*\))?$/i.test(name);
}

export async function titlesFor(xuid: string): Promise<{ titleId: string; name: string }[]> {
  return cached(`titles:${xuid}`, 30 * 60_000, async () => {
    const data = object(await provider(`/v2/titles/${xuid}`));
    if (!Array.isArray(data.titles)) throw new XboxError(502, "Xbox title history is incomplete or private.");
    return array(data.titles).map(raw => {
      const row = object(raw);
      return { titleId: identifier(row.titleId), name: text(row.name), achievement: object(row.achievement) };
    // Xbox history can report totalAchievements=0 even with unlocked achievements.
    // Title names identify Bedrock; achievement availability is checked on fetch.
    }).filter(row => validId(row.titleId) && isBedrockTitle(row.name))
      .map(({ titleId, name }) => ({ titleId, name }));
  });
}

export async function lookupPublicPlayer(tag: string) {
  return cached(`lookup:${tag.toLocaleLowerCase()}`, 15 * 60_000, async () => {
    const data = object(await provider(`/v2/search/${encodeURIComponent(tag)}`));
    if (!Array.isArray(data.people)) throw new XboxError(502, "Xbox player search is incomplete or private.");
    // Search is fuzzy: never silently select a different person's account.
    const player = array(data.people).map(object).find(p => text(p.gamertag).toLocaleLowerCase() === tag.toLocaleLowerCase());
    if (!player || !validId(player.xuid)) throw new XboxError(404, "Exact gamertag not found, or profile is private.");
    const xuid = identifier(player.xuid);
    return { xuid, gamertag: text(player.gamertag) };
  });
}

export async function lookupPlayer(tag: string) {
  const player = await lookupPublicPlayer(tag);
  return { ...player, titles: await titlesFor(player.xuid) };
}

export type PresenceResult = {
  xuid: string;
  status: "online" | "offline" | "away" | "unknown";
  xboxLastSeenAt: string | null;
  checkedAt: string;
  error: string | null;
};

export function normalizePresence(raw: unknown, xuid: string, checkedAt: string): PresenceResult {
  const row = object(raw);
  const state = text(row.state);
  // Only a matching, explicit state confirms presence. Missing/private data is unknown.
  const status = identifier(row.xuid) !== xuid ? "unknown"
    : state === "Online" || state === "Busy" ? "online"
    : state === "Away" ? "away" : state === "Offline" ? "offline" : "unknown";
  const time = unlockTime(object(row.lastSeen).timestamp);
  const calendarDate = time ? time.slice(0, 10) : "";
  const calendarValid = !!time && new Date(`${calendarDate}T00:00:00Z`).toISOString().slice(0, 10) === calendarDate;
  // Reject sentinel, future, malformed and ambiguous dates. Never infer last seen
  // from title activity, refresh time, or the transition to offline.
  const xboxLastSeenAt = status !== "unknown" && time && calendarValid && Date.parse(time) >= Date.UTC(2000, 0, 1) &&
    Date.parse(time) <= Date.parse(checkedAt) ? time : null;
  return { xuid, status, xboxLastSeenAt, checkedAt,
    error: status === "unknown" ? "Public presence is unavailable or private." : null };
}

const presenceTimes: number[] = [];
export async function publicPresence(xuids: string[]) {
  const ids = [...new Set(xuids)].sort();
  if (!ids.length || ids.length > 8 || !ids.every(validId))
    throw new XboxError(400, "Provide one to eight valid Xbox identifiers.");
  // The documented legacy comma-separated route returns code:400 in practice.
  // Use the current single-player route, amortizing its calls over a longer
  // interval for larger lists. Share cached/in-flight results across watchlists.
  const pollAfterSeconds = 120 * ids.length;
  const players = await Promise.all(ids.map(xuid =>
    // Freshness is independent of the watchlist that first requested a player.
    // Larger lists poll less often, but must not hold smaller lists to an old TTL.
    cached(`presence-player:${xuid}`, 120_000, async () => {
      try {
        const now = Date.now();
        while (presenceTimes.length && presenceTimes[0] <= now - 3_600_000) presenceTimes.shift();
        // Preserve the tracker ceiling of 30 calls/hour across all visitors,
        // leaving 90 of the shared 120/hour allowance for other Xbox lookups.
        if (presenceTimes.length >= 30)
          throw new XboxError(429, "Online Tracker's shared hourly allowance is used. Try again later.");
        presenceTimes.push(now);
        const data = await provider(`/v2/presence/${xuid}`);
        const rows = Array.isArray(data) ? data : [data];
        return normalizePresence(rows.find(raw => identifier(object(raw).xuid) === xuid),
          xuid, new Date().toISOString());
      } catch (error) {
        // A private/missing player or provider failure must not discard the
        // rest of the list, masquerade as offline, or cause rapid retry storms.
        if (!(error instanceof XboxError)) throw error;
        return { ...normalizePresence(null, xuid, new Date().toISOString()), error: error.message };
      }
    })));
  return { players, pollAfterSeconds };
}

export async function playerAchievements(xuid: string, titleId: string) {
  const titles = await titlesFor(xuid);
  if (!titles.some(title => title.titleId === titleId))
    throw new XboxError(404, "This player has no public Minecraft Bedrock achievements for that title.");
  return cached(`achievements:${xuid}:${titleId}`, 15 * 60_000, async () => {
    const results: { id: string; name: string; achieved: boolean; unlockedAt: string | null }[] = [];
    const seen = new Set<string>();
    const seenTokens = new Set<string>();
    let token: string | undefined;
    let total = 0;
    for (let page = 0; page < 40; page++) {
      const path = `/v2/achievements/player/${xuid}/${titleId}${token ? `?continuationToken=${encodeURIComponent(token)}` : ""}`;
      const data = object(await provider(path));
      const paging = object(data.pagingInfo);
      if (!Array.isArray(data.achievements) || !("continuationToken" in paging))
        throw new XboxError(502, "Xbox achievement list is incomplete or private.");
      for (const raw of data.achievements) {
        const row = object(raw);
        if (!array(row.titleAssociations).some(a => identifier(object(a).id) === titleId))
          throw new XboxError(502, "Xbox achievement list contains entries for another title.");
        if (!text(row.name) || !text(row.id) || !text(row.progressState))
          throw new XboxError(502, "Xbox achievement list contains incomplete entries.");
        const id = `${text(row.serviceConfigId)}:${text(row.id)}`;
        if (!seen.has(id)) {
          seen.add(id);
          const achieved = row.progressState === "Achieved" && row.isRevoked !== true;
          results.push({
            id, name: text(row.name), achieved,
            unlockedAt: achieved ? unlockTime(object(row.progression).timeUnlocked) : null,
          });
        }
      }
      total += data.achievements.length;
      const next = paging.continuationToken;
      if (next === null || next === "") {
        if (typeof paging.totalRecords === "number" && total < paging.totalRecords)
          throw new XboxError(502, "Xbox achievement pagination ended before all records were returned.");
        return { achievements: results, refreshedAt: new Date().toISOString() };
      }
      if (typeof next !== "string" || next.length > 512 || next === token || seenTokens.has(next))
        throw new XboxError(502, "Xbox achievement pagination could not complete.");
      seenTokens.add(next);
      token = next;
    }
    throw new XboxError(502, "Xbox achievement list exceeds the safe pagination limit.");
  });
}