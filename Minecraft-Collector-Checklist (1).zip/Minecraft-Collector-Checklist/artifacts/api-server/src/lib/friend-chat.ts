import { createHash, createHmac, randomBytes, randomUUID } from "node:crypto";

export const ROOM_TTL_MS = 24 * 60 * 60 * 1000;
export const MAX_PARTICIPANTS = 12;
export const MAX_HISTORY = 200;
export const PAGE_SIZE = 100;
export const NICK_MAX = 24;
export const BODY_MAX = 500;

export const newSecret = () => randomBytes(32).toString("base64url");
export const hashSecret = (secret: string) => createHash("sha256").update(secret).digest("hex");
export const newId = () => randomUUID();

/** Trim, collapse whitespace, strip control chars. Returns null if invalid. */
export function cleanNickname(value: string): string | null {
  const v = value.normalize("NFKC").replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g, "").replace(/\s+/g, " ").trim();
  return v.length >= 1 && v.length <= NICK_MAX ? v : null;
}
export function cleanBody(value: string): string | null {
  const v = value.replace(/\r\n?/g, "\n").replace(/[\u0000-\u0008\u000b-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "").replace(/\n{4,}/g, "\n\n\n").trim();
  return v.length >= 1 && v.length <= BODY_MAX ? v : null;
}

/** Simple fixed-window limiter keyed by an HMAC of the identifier (raw IPs/tokens never kept). */
export function createLimiter(limit: number, windowMs: number) {
  const key = randomBytes(32);
  const buckets = new Map<string, { count: number; expires: number }>();
  return (id: string, now = Date.now()): boolean => {
    if (buckets.size > 5000) for (const [k, b] of buckets) if (b.expires <= now) buckets.delete(k);
    const k = createHmac("sha256", key).update(id).digest("hex");
    const b = buckets.get(k);
    if (!b || b.expires <= now) { buckets.set(k, { count: 1, expires: now + windowMs }); return true; }
    if (b.count >= limit) return false;
    b.count++;
    return true;
  };
}
