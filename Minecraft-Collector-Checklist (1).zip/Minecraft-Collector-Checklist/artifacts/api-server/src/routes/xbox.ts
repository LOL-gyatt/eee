import { Router, type IRouter } from "express";
import {
  LookupXboxPlayerBody, LookupXboxPlayerResponse,
  GetXboxAchievementsQueryParams, GetXboxAchievementsResponse,
  LookupXboxTrackerPlayerBody, LookupXboxTrackerPlayerResponse,
  GetXboxTrackerPresenceBody, GetXboxTrackerPresenceResponse,
} from "@workspace/api-zod";
import { lookupPlayer, lookupPublicPlayer, publicPresence, playerAchievements, validGamertag, XboxError } from "../lib/xbox";

const router: IRouter = Router();
const fail = (error: unknown, res: import("express").Response) => {
  const known = error instanceof XboxError ? error : new XboxError(502, "Xbox data could not be loaded. Please try again later.");
  res.status(known.status).json({ error: known.message });
};

router.post("/xbox/tracker/lookup", async (req, res): Promise<void> => {
  const body = LookupXboxTrackerPlayerBody.safeParse(req.body);
  if (!body.success || !validGamertag(body.data.gamertag)) {
    res.status(400).json({ error: "Enter an exact valid gamertag (up to 30 characters)." });
    return;
  }
  try { res.json(LookupXboxTrackerPlayerResponse.parse(await lookupPublicPlayer(body.data.gamertag))); }
  catch (error) { fail(error, res); }
});

router.post("/xbox/tracker/presence", async (req, res): Promise<void> => {
  const body = GetXboxTrackerPresenceBody.safeParse(req.body);
  if (!body.success || new Set(body.data.xuids).size !== body.data.xuids.length ||
      Object.keys(req.body).some(key => key !== "xuids")) {
    res.status(400).json({ error: "Provide one to eight unique valid Xbox identifiers." });
    return;
  }
  try { res.json(GetXboxTrackerPresenceResponse.parse(await publicPresence(body.data.xuids))); }
  catch (error) { fail(error, res); }
});

router.post("/xbox/lookup", async (req, res): Promise<void> => {
  const body = LookupXboxPlayerBody.safeParse(req.body);
  if (!body.success || !validGamertag(body.data.gamertag)) {
    res.status(400).json({ error: "Enter a valid gamertag (up to 30 characters)." });
    return;
  }
  try {
    res.json(LookupXboxPlayerResponse.parse(await lookupPlayer(body.data.gamertag)));
  } catch (error) { fail(error, res); }
});

router.get("/xbox/achievements", async (req, res): Promise<void> => {
  const query = GetXboxAchievementsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: "Invalid Xbox player or title identifier." });
    return;
  }
  try {
    res.json(GetXboxAchievementsResponse.parse(await playerAchievements(query.data.xuid, query.data.titleId)));
  } catch (error) { fail(error, res); }
});

export default router;