import { Router, type IRouter, type Request, type Response } from "express";
import { and, asc, desc, eq, gt, isNull, lt, lte, sql, count, inArray } from "drizzle-orm";
import { db, friendRoomsTable, friendParticipantsTable, friendMessagesTable } from "@workspace/db";
import {
  CreateFriendRoomBody, JoinFriendRoomBody, ListFriendMessagesBody, SendFriendMessageBody, LeaveFriendRoomBody,
} from "@workspace/api-zod";
import {
  ROOM_TTL_MS, MAX_PARTICIPANTS, MAX_HISTORY, PAGE_SIZE, newSecret, hashSecret, newId, cleanNickname, cleanBody, createLimiter,
} from "../lib/friend-chat";

// Privacy: room keys and tokens travel only in JSON bodies (never URLs) and are
// stored as SHA-256 hashes. Nothing here logs request bodies.
const router: IRouter = Router();
const createLimit = createLimiter(6, 10 * 60_000);
const joinLimit = createLimiter(20, 10 * 60_000);
const sendLimit = createLimiter(20, 60_000);
const readLimit = createLimiter(90, 60_000);
const ip = (req: Request) => req.ip ?? req.socket.remoteAddress ?? "unknown";
const fail = (res: Response, status: number, error: string) => { res.status(status).json({ error }); };
const iso = (d: Date) => d.toISOString();

async function purgeExpired() {
  await db.delete(friendRoomsTable).where(lte(friendRoomsTable.expiresAt, new Date()));
}

async function session(token: string) {
  const [row] = await db.select({ p: friendParticipantsTable, r: friendRoomsTable })
    .from(friendParticipantsTable)
    .innerJoin(friendRoomsTable, eq(friendParticipantsTable.roomId, friendRoomsTable.id))
    .where(and(eq(friendParticipantsTable.tokenHash, hashSecret(token)), isNull(friendParticipantsTable.leftAt)));
  if (!row || row.r.expiresAt <= new Date()) return null;
  return row;
}

router.use("/friend-chat", (_req, res, next) => { res.setHeader("Cache-Control", "no-store"); next(); });

router.post("/friend-chat/rooms", async (req, res): Promise<void> => {
  const body = CreateFriendRoomBody.strict().safeParse(req.body);
  const nickname = body.success ? cleanNickname(body.data.nickname) : null;
  if (!nickname) return fail(res, 400, "Choose a nickname of 1–24 characters.");
  if (!createLimit(ip(req))) return fail(res, 429, "Too many rooms created. Try again in a few minutes.");
  await purgeExpired();
  const roomKey = newSecret(), token = newSecret();
  const roomId = newId(), participantId = newId();
  const expiresAt = new Date(Date.now() + ROOM_TTL_MS);
  await db.transaction(async tx => {
    await tx.insert(friendRoomsTable).values({ id: roomId, keyHash: hashSecret(roomKey), expiresAt });
    await tx.insert(friendParticipantsTable).values({ id: participantId, roomId, nickname, tokenHash: hashSecret(token) });
  });
  res.status(201).json({ roomKey, token, participantId, nickname, expiresAt: iso(expiresAt) });
});

router.post("/friend-chat/rooms/join", async (req, res): Promise<void> => {
  const body = JoinFriendRoomBody.strict().safeParse(req.body);
  const nickname = body.success ? cleanNickname(body.data.nickname) : null;
  if (!body.success || !nickname) return fail(res, 400, "Check the invite link and choose a nickname of 1–24 characters.");
  if (!joinLimit(ip(req))) return fail(res, 429, "Too many join attempts. Try again in a few minutes.");
  const [room] = await db.select().from(friendRoomsTable).where(eq(friendRoomsTable.keyHash, hashSecret(body.data.roomKey)));
  if (!room || room.expiresAt <= new Date()) return fail(res, 404, "This invite is invalid or the room has expired.");
  const token = newSecret(), participantId = newId();
  const ok = await db.transaction(async tx => {
    await tx.execute(sql`select id from friend_rooms where id = ${room.id} for update`);
    const [{ n }] = await tx.select({ n: count() }).from(friendParticipantsTable)
      .where(and(eq(friendParticipantsTable.roomId, room.id), isNull(friendParticipantsTable.leftAt)));
    if (n >= MAX_PARTICIPANTS) return false;
    await tx.insert(friendParticipantsTable).values({ id: participantId, roomId: room.id, nickname, tokenHash: hashSecret(token) });
    return true;
  });
  if (!ok) return fail(res, 409, `This room is full (${MAX_PARTICIPANTS} people maximum).`);
  res.json({ roomKey: body.data.roomKey, token, participantId, nickname, expiresAt: iso(room.expiresAt) });
});

router.post("/friend-chat/messages/list", async (req, res): Promise<void> => {
  const body = ListFriendMessagesBody.strict().safeParse(req.body);
  if (!body.success || (body.data.after !== undefined && !Number.isSafeInteger(body.data.after))) return fail(res, 400, "Invalid request.");
  const s = await session(body.data.token);
  if (!s) return fail(res, 401, "Your chat session ended or the room expired.");
  if (!readLimit(s.p.id)) return fail(res, 429, "Checking too often. Slow down.");
  const after = body.data.after ?? 0;
  const rows = after > 0
    ? await db.select().from(friendMessagesTable)
      .where(and(eq(friendMessagesTable.roomId, s.r.id), gt(friendMessagesTable.id, after)))
      .orderBy(asc(friendMessagesTable.id)).limit(PAGE_SIZE)
    : (await db.select().from(friendMessagesTable).where(eq(friendMessagesTable.roomId, s.r.id))
      .orderBy(desc(friendMessagesTable.id)).limit(PAGE_SIZE)).reverse();
  const people = await db.select({ participantId: friendParticipantsTable.id, nickname: friendParticipantsTable.nickname })
    .from(friendParticipantsTable)
    .where(and(eq(friendParticipantsTable.roomId, s.r.id), isNull(friendParticipantsTable.leftAt)))
    .orderBy(asc(friendParticipantsTable.joinedAt));
  res.json({
    messages: rows.map(m => ({ id: m.id, participantId: m.participantId, nickname: m.nickname, body: m.body, createdAt: iso(m.createdAt) })),
    participants: people,
    self: { participantId: s.p.id, nickname: s.p.nickname },
    expiresAt: iso(s.r.expiresAt),
    maxParticipants: MAX_PARTICIPANTS,
  });
});

router.post("/friend-chat/messages", async (req, res): Promise<void> => {
  const body = SendFriendMessageBody.strict().safeParse(req.body);
  const text = body.success ? cleanBody(body.data.body) : null;
  if (!body.success || !text) return fail(res, 400, "Messages must be 1–500 characters.");
  const s = await session(body.data.token);
  if (!s) return fail(res, 401, "Your chat session ended or the room expired.");
  const [existing] = await db.select().from(friendMessagesTable)
    .where(and(eq(friendMessagesTable.participantId, s.p.id), eq(friendMessagesTable.clientId, body.data.clientId)));
  let m = existing;
  if (!m) {
    if (!sendLimit(s.p.id)) return fail(res, 429, "You're sending too fast. Wait a moment.");
    const [inserted] = await db.insert(friendMessagesTable)
      .values({ roomId: s.r.id, participantId: s.p.id, nickname: s.p.nickname, body: text, clientId: body.data.clientId, length: text.length })
      .onConflictDoNothing().returning();
    m = inserted ?? (await db.select().from(friendMessagesTable)
      .where(and(eq(friendMessagesTable.participantId, s.p.id), eq(friendMessagesTable.clientId, body.data.clientId))))[0];
    // Bounded history: keep only the newest MAX_HISTORY messages per room.
    const old = await db.select({ id: friendMessagesTable.id }).from(friendMessagesTable)
      .where(eq(friendMessagesTable.roomId, s.r.id)).orderBy(desc(friendMessagesTable.id)).offset(MAX_HISTORY).limit(1);
    if (old[0]) await db.delete(friendMessagesTable).where(and(eq(friendMessagesTable.roomId, s.r.id), lt(friendMessagesTable.id, old[0].id + 1)));
  }
  res.status(201).json({ id: m.id, participantId: m.participantId, nickname: m.nickname, body: m.body, createdAt: iso(m.createdAt) });
});

router.post("/friend-chat/leave", async (req, res): Promise<void> => {
  const body = LeaveFriendRoomBody.strict().safeParse(req.body);
  if (!body.success) return fail(res, 401, "Session invalid.");
  const s = await session(body.data.token);
  if (!s) return fail(res, 401, "Session already ended.");
  await db.update(friendParticipantsTable).set({ leftAt: new Date() }).where(eq(friendParticipantsTable.id, s.p.id));
  const [{ n }] = await db.select({ n: count() }).from(friendParticipantsTable)
    .where(and(eq(friendParticipantsTable.roomId, s.r.id), isNull(friendParticipantsTable.leftAt)));
  if (n === 0) await db.delete(friendRoomsTable).where(inArray(friendRoomsTable.id, [s.r.id]));
  res.json({ left: true });
});

export default router;
