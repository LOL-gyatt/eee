// Integration test: run with FRIEND_CHAT_API=http://localhost:PORT/api node --test
import assert from 'node:assert/strict';
import { test } from 'node:test';
const API = process.env.FRIEND_CHAT_API ?? 'http://localhost:8099/api';
const post = async (path, body) => { const r = await fetch(API + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.status, body: await r.json() }; };

test('two guests: create, join, send, read, isolation, dedupe, leave', async () => {
  const a = await post('/friend-chat/rooms', { nickname: '  Alex  ' });
  assert.equal(a.status, 201); assert.equal(a.body.nickname, 'Alex'); assert.match(a.body.roomKey, /^[A-Za-z0-9_-]{43}$/);
  assert.equal((await post('/friend-chat/rooms/join', { roomKey: 'x'.repeat(43), nickname: 'Eve' })).status, 404);
  const b = await post('/friend-chat/rooms/join', { roomKey: a.body.roomKey, nickname: 'Sam' });
  assert.equal(b.status, 200); assert.notEqual(b.body.token, a.body.token);
  // spoofed sender fields rejected by strict schema
  assert.equal((await post('/friend-chat/messages', { token: b.body.token, body: 'hi', clientId: 'abcdefgh1', participantId: a.body.participantId })).status, 400);
  const m1 = await post('/friend-chat/messages', { token: b.body.token, body: '<b>hi</b>', clientId: 'abcdefgh1' });
  assert.equal(m1.status, 201); assert.equal(m1.body.participantId, b.body.participantId); assert.equal(m1.body.body, '<b>hi</b>');
  const dup = await post('/friend-chat/messages', { token: b.body.token, body: '<b>hi</b>', clientId: 'abcdefgh1' });
  assert.equal(dup.body.id, m1.body.id);
  assert.equal((await post('/friend-chat/messages', { token: b.body.token, body: 'x'.repeat(501), clientId: 'abcdefgh2' })).status, 400);
  const la = await post('/friend-chat/messages/list', { token: a.body.token });
  assert.equal(la.status, 200); assert.equal(la.body.messages.length, 1); assert.equal(la.body.participants.length, 2); assert.equal(la.body.self.participantId, a.body.participantId);
  assert.equal((await post('/friend-chat/messages/list', { token: a.body.token, after: m1.body.id })).body.messages.length, 0);
  // another room cannot see it
  const c = await post('/friend-chat/rooms', { nickname: 'Other' });
  assert.equal((await post('/friend-chat/messages/list', { token: c.body.token })).body.messages.length, 0);
  assert.equal((await post('/friend-chat/messages/list', { token: 'y'.repeat(43) })).status, 401);
  assert.equal((await post('/friend-chat/leave', { token: b.body.token })).status, 200);
  assert.equal((await post('/friend-chat/messages', { token: b.body.token, body: 'after', clientId: 'abcdefgh3' })).status, 401);
  assert.equal((await post('/friend-chat/messages/list', { token: b.body.token })).status, 401);
  assert.equal((await post('/friend-chat/messages/list', { token: a.body.token })).body.participants.length, 1);
  await post('/friend-chat/leave', { token: a.body.token }); await post('/friend-chat/leave', { token: c.body.token });
});
