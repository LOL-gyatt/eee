import { createHmac, randomBytes } from "node:crypto";
import { Router, type IRouter } from "express";
import { SendMinecraftChatBody, SendMinecraftChatResponse } from "@workspace/api-zod";
import { CHAT_TIMEOUT_MS, generateMinecraftAnswer, MINECRAFT_MODEL, validChatHistory } from "../lib/minecraft-chat";

const router: IRouter = Router();
// Ephemeral hashed network identifiers only; never store/log prompts or profiles.
const hashKey = randomBytes(32);
const buckets = new Map<string, { count: number; expires: number; active: boolean }>();
let inFlight = 0;
let hourly = { count: 0, expires: Date.now() + 3_600_000 };

router.post("/openai/minecraft/chat", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const parsed = SendMinecraftChatBody.strict().safeParse(req.body);
  if (!parsed.success || !validChatHistory(parsed.data)) {
    res.status(400).json({ error: "Send a question of 1–1500 characters and up to 4 completed conversation turns (16000 history characters maximum)." });
    return;
  }
  if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || !process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
    res.status(503).json({ error: "Replit AI is not configured on this server. Tracking still works; please try again after the integration is enabled." });
    return;
  }
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.expires <= now && !bucket.active) buckets.delete(key);
  }
  const key = createHmac("sha256", hashKey).update(req.ip ?? req.socket.remoteAddress ?? "unknown").digest("hex");
  let bucket = buckets.get(key);
  if (!bucket) {
    if (buckets.size >= 1000) {
      res.setHeader("Retry-After", "60");
      res.status(429).json({ error: "AI is busy. Please try again in a minute.", retryAfterSeconds: 60 });
      return;
    }
    bucket = { count: 0, expires: now + 60_000, active: false };
    buckets.set(key, bucket);
  }
  if (hourly.expires <= now) hourly = { count: 0, expires: now + 3_600_000 };
  if (bucket.expires <= now) { bucket.count = 0; bucket.expires = now + 60_000; }
  const retryAfterSeconds = Math.max(1, Math.ceil(((hourly.count >= 120 ? hourly.expires : bucket.expires) - now) / 1000));
  if (bucket.active || bucket.count >= 6 || inFlight >= 3 || hourly.count >= 120) {
    const wait = bucket.active || inFlight >= 3 ? 5 : retryAfterSeconds;
    res.setHeader("Retry-After", String(wait));
    res.status(429).json({ error: `AI is busy or the request limit was reached. Try again in ${wait} seconds.`, retryAfterSeconds: wait });
    return;
  }
  bucket.count++;
  bucket.active = true;
  hourly.count++;
  inFlight++;
  const controller = new AbortController();
  let timedOut = false;
  const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, CHAT_TIMEOUT_MS);
  const onClose = () => { if (!res.writableEnded) controller.abort(); };
  res.on("close", onClose);
  try {
    const answer = await generateMinecraftAnswer(parsed.data, controller.signal);
    if (!controller.signal.aborted) res.json(SendMinecraftChatResponse.parse({ answer, model: MINECRAFT_MODEL }));
  } catch (error) {
    if (res.destroyed) return;
    const upstreamStatus = error && typeof error === "object" && "status" in error ? Number(error.status) : 0;
    const isTimeout = timedOut || (error instanceof Error && error.name === "APIConnectionTimeoutError");
    // Never log SDK error objects: they can contain request data or credentials.
    req.log.warn({ upstreamStatus, timedOut: isTimeout }, "Minecraft AI request failed");
    if (isTimeout) {
      res.status(504).json({ error: "The AI took too long to respond. Please retry, or ask a shorter question." });
    } else if (upstreamStatus === 429) {
      res.setHeader("Retry-After", "30");
      res.status(429).json({ error: "Replit AI is rate limited or its credit allowance is unavailable. Wait 30 seconds before retrying; check your Replit AI credits if this continues.", retryAfterSeconds: 30 });
    } else {
      res.status(502).json({ error: "Replit AI could not answer right now. Please retry. If this continues, check the integration and available Replit AI credits." });
    }
  } finally {
    clearTimeout(timeout);
    res.off("close", onClose);
    bucket.active = false;
    inFlight--;
  }
});

export default router;