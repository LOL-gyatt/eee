import { Router, type IRouter } from "express";
import healthRouter from "./health";
import xboxRouter from "./xbox";
import minecraftChatRouter from "./minecraft-chat";

const router: IRouter = Router();

router.use(healthRouter);
router.use(xboxRouter);
router.use(minecraftChatRouter);
// Chat's optional database must not prevent stateless Xbox routes from starting.
// Keep the original path intact for the chat router's /friend-chat routes.
router.use(async (req, res, next) => {
  if (req.path !== "/friend-chat" && !req.path.startsWith("/friend-chat/")) { next(); return; }
  res.setHeader("Cache-Control", "no-store");
  try {
    const { default: friendChatRouter } = await import("./friend-chat");
    friendChatRouter(req, res, next);
  } catch {
    res.status(503).json({ error: "Friend chat is not configured right now. Please try again later." });
  }
});

export default router;
