import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
// Parse AI bodies before the general parser so oversized chat requests cannot
// consume the normal API's larger body allowance.
app.use("/api/openai/minecraft/chat", (req, res, next) => {
  if (req.method === "POST" && !req.is("application/json")) {
    res.status(400).json({ error: "Chat requests must use application/json." });
    return;
  }
  next();
});
app.use("/api/openai/minecraft/chat", express.json({ limit: "32kb" }));
app.use("/api/friend-chat", express.json({ limit: "8kb" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);
app.use((error: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (!req.path.startsWith("/api/openai/minecraft/chat")) { next(error); return; }
  const status = error && typeof error === "object" && "status" in error ? Number(error.status) : 500;
  res.status(status === 413 ? 413 : status === 400 ? 400 : 502).json({
    error: status === 413 ? "Chat request is too large (32 KB maximum). Clear the chat or shorten your question."
      : status === 400 ? "Chat request contains invalid JSON."
        : "The AI service could not complete the request. Please try again.",
  });
});

export default app;
